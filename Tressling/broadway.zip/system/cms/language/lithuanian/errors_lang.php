<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Toks puslapis nerastas';
$lang['error_404_message'] = 'Negalime surasti tokio puslapio, spauskite <a href="%s">čia</a> kad patektumėte į namų puslapį.';

// Database
$lang['error_invalid_db_group'] = 'Grupė "%s" duombazė netinkao konfiguracijos.';

/* End of file errors_lang.php */