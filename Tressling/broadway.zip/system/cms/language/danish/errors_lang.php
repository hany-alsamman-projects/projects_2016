<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Side mangler';
$lang['error_404_message'] = 'Vi kan ikke finde den ønskede side. Klik venligst her <a href="%s">here</a> for at gå tilbage til startsiden.';

// Database
$lang['error_invalid_db_group'] = 'Databasen forsøger at bruge en ugyldig konfigurationsgruppe "%s".';

/* End of file errors_lang.php */
/* Location: ./system/cms/language/english/errors_lang.php */
