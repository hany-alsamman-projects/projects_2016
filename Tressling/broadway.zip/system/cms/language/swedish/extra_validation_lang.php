<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "Fältet %s får endast innehålla alfanumeriska tecken, understreck, snedstreck och punkter.";
$lang['decimal']				= "Fältet %s måste innehålla ett decimaltal.";
$lang['csrf_bad_token']			= "Ogiltig CSRF token";

/* End of file extra_validation_lang.php */