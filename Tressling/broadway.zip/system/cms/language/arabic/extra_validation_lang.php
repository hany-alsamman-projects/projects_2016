<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "الحقل %s يمكن أن يحتوي أحرفاً وأرقاماً وعلامة - والنقطة فقط أو ";
$lang['decimal']				= "الحقل %s يجب أن يحتوي أرقام عشريّة فقط.";
$lang['csrf_bad_token']			= "رمز CSRF غير صالح";

/* End of file extra_validation_lang.php */