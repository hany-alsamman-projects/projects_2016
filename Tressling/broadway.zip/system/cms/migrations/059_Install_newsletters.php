<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Install_newsletters extends CI_Migration {

	public function up()
	{
		// Nothing to see here... move along... move along...
		return TRUE;
	}

	public function down()
	{
		return TRUE;
	}
}