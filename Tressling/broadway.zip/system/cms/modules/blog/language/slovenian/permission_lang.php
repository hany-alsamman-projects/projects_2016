<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Objavi članek';
$lang['blog.role_edit_live']	= 'Uredi objavljen članek';
$lang['blog.role_delete_live'] 	= 'Izbriši objavljen članek';

// slovenian premission_lang.php