<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "

<h4>Ikhtisar</h4>
<p>
	Modul Blog adalah alat sederhana untuk penerbitan entri blog.
</p>

<h4> Kategori </h4>
<p>
	Anda dapat membuat kategori sebanyak yang Anda ingin untuk mengatur posting Anda. Jika Anda ingin pengunjung Anda
	dapat menelusuri menurut kategori cukup pasang widget Blog Kategori di halaman depan.
</p>

<h4> Tulisan </h4>
<p>
Pilih judul yang baik untuk posting Anda karena mereka akan ditampilkan pada halaman Blog utama (bersama dengan pendahuluan)
dan juga akan digunakan sebagai judul dalam hasil mesin pencari. Setelah membuat posting Anda dapat menyimpannya sebagai Publikasikan untuk menerbitkannya atau
Anda dapat menyimpannya sebagai Draft jika Anda ingin kembali dan mengedit nanti. Anda juga dapat menyimpannya sebagai Publikasikan namun mengatur tanggal
di masa depan dan posting Anda tidak akan menunjukkan sampai dengan tanggal yang dicapai.
</p>

";
