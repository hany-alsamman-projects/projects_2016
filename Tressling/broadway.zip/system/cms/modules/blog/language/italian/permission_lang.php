<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Pubblicare nuovi articoli';
$lang['blog.role_edit_live']	= 'Modificare articoli pubblicati'; 
$lang['blog.role_delete_live'] 	= 'Cancellare articoli pubblicati'; 