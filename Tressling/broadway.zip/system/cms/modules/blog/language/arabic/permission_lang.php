<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live'] = 'نشر التدوينات';
$lang['blog.role_edit_live'] = 'تعديل التدوينات المنشورة';
$lang['blog.role_delete_live'] 	= 'حذف التدوينات المنشورة';
