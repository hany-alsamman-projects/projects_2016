<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
* Author: Thanh Nguyen
* 		  nguyenhuuthanh@gmail.com
*
* Location: http://techmix.net
*
* Created:  10.26.2011
*
* Description:  Vietnamese language file
*
*/
// Blog Permissions
$lang['blog.role_put_live']		= 'Đưa bài viết lên site';
$lang['blog.role_edit_live']	= 'Sửa bài viết';
$lang['blog.role_delete_live'] 	= 'Xóa bài viết';