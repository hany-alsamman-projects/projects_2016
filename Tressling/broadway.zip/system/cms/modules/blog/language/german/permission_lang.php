<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Artikel live setzen';
$lang['blog.role_edit_live']	= 'Live-Artikel bearbeiten';
$lang['blog.role_delete_live'] 	= 'Live-Artikel l&ouml;schen';

/* End of file permission_lang.php */