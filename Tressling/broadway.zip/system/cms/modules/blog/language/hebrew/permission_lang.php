<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live'] = 'הכנס מאמרים חיים';
$lang['blog.role_edit_live'] = 'ערוך מאמרים חיים';
$lang['blog.role_delete_live'] 	= 'Delete live articles'; #translate