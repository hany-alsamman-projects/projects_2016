<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Bejegyzés élővé tétele';
$lang['blog.role_edit_live']            = 'Élő bejegyzés szerkesztése';
$lang['blog.role_delete_live']          = 'Élő bejegyzés törlése';