<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Put articles live';
$lang['blog.role_edit_live']	= 'Edit live articles';
$lang['blog.role_delete_live'] 	= 'Delete live articles';