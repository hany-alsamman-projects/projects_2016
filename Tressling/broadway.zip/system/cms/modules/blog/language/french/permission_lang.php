<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Mettre l\'article en direct';
$lang['blog.role_edit_live']	= 'Modifier les articles en direct';
$lang['blog.role_delete_live'] 	= 'Supprimer les articles en direct';