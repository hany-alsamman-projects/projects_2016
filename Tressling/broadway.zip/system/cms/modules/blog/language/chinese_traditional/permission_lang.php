<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= '將文章上線';
$lang['blog.role_edit_live']	= '編輯上線文章';
$lang['blog.role_delete_live'] 	= '刪除上線文章';