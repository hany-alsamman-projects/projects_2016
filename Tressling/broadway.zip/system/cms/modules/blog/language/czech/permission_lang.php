<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Publikování příspěvků';
$lang['blog.role_edit_live']	= 'Úpravy publikovaných příspěvků';
$lang['blog.role_delete_live'] 	= 'Mazání publikovaných příspěvků';