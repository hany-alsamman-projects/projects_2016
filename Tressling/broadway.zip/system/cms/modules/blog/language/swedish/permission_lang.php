<?php defined('BASEPATH') or exit('No direct script access allowed');


$lang['blog.role_put_live'] = 'Publicera artiklar';
$lang['blog.role_edit_live'] = 'Redigera publika artiklar';
$lang['blog.role_delete_live'] = 'Radera publika artiklar';



/* End of file permission_lang.php */  
/* Location: ./system/cms/modules/blog/language/english */ 