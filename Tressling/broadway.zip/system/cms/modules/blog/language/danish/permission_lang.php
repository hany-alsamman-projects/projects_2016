<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Læg artikler online';
$lang['blog.role_edit_live']	= 'Redigér online artikler';
$lang['blog.role_delete_live'] 	= 'Slet online artikler';