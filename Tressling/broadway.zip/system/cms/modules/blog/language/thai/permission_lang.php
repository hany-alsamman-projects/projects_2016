<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
* Thai translation.
*
* @author	Nateetorn Lertkhonsan <nateetorn.l@gmail.com>
* @package	PyroCMS  
* @link		http://pyrocms.com
* @date		2012-04-19
* @version	1.0.0
**/

// Blog Permissions
$lang['blog.role_put_live']		= 'วางบทบทความไลฟ์';
$lang['blog.role_edit_live']	= 'แก้ไขบทความไลฟ์';
$lang['blog.role_delete_live'] 	= 'ลบบทความไลฟ์';