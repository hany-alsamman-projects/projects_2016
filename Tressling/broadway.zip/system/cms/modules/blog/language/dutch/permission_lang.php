<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Zet artikelen online';
$lang['blog.role_edit_live']	= 'Bewerk online artikelen';
$lang['blog.role_delete_live'] 	= 'Verwijder online artikelen';