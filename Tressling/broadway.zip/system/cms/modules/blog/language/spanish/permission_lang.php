<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live']		= 'Colocar artículos disponibles';
$lang['blog.role_edit_live']	= 'Editar artículos disponibles';
$lang['blog.role_delete_live'] 	= 'Eliminar artículos disponibles';