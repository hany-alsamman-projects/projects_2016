<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['blog.role_put_live'] = 'Įdėti straipsnį gyvai';
$lang['blog.role_edit_live'] = 'Straipsnių gyvai redagavimas';
$lang['blog.role_delete_live'] 	= 'Delete live articles'; #translate