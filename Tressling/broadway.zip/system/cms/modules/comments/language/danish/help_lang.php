<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "
<h4>Oversigt</h4>
<p>Kommentar modulet, tillader besøgende at kommetere på en hvilken som helst del af din hjemmeside som du tillader kommentarer for.</p>

<h4>Tillad Kommentarer</h4><hr>
<p>Kommentarer kan tillades for sider, gallerier og blog. Hvis du ønsker at moderere kommentarer, skal du slå kommentarmoderation til i indstillinger.</p>

<h4>Kommentar Moderation</h4><hr>
<p>Kommentarer kan blive godkendt eller afvist på et givent tidspunkt fra admin panelet. Hvis du vil godkende en kommentar og senere afvise den, kan du også gøre det.</p>";