<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "
<h4> Ikhtisar </h4>
<p> Modul komentar memungkinkan pengunjung memberikan komentar pada setiap bagian dari situs Anda yang Anda perbolehkan untuk berkomentar. </p>

<h4> Mengaktifkan Komentar </h4> <hr>
Komentar <p> dapat diaktifkan pada Halaman, Galeri, dan Blog. Jika Anda ingin memoderasi komentar Anda harus mengaktifkan moderasi komentar di Pengaturan. </p>

Moderasi Komentar <h4> </h4> <hr>
Komentar <p> mungkin Disetujui atau Belum Disetujui setiap saat dari panel admin. Jika Anda menyetujui komentar dan kemudian ingin melepas persetujuan itu Anda dapat melakukannya.</p>";
