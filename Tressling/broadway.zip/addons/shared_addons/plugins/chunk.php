    <?php defined('BASEPATH') OR exit('No direct script access allowed');
    /**
    * Page Chunks Plugin
    *
    * Read specified page chunk
    *
    * @package PyroCMS
    * @author michalsn
    * @copyright Copyright (c) 2008 - 2011, PyroCMS
    *
    */
    class Plugin_Page extends Plugin
    {
    /**
    * Data
    *
    * Loads a page chunk
    *
    * Usage:
    * {pyro:page:chunk id="0"}
    *
    * @param array
    * @return string
    */
    function chunk()
    {
    echo 'sssssssssss';
    }
     
    }