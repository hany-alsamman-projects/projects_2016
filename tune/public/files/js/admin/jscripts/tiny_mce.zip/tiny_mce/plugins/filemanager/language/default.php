<?php
	require_once("language.php");
?>