<?php
$INFO['MetaAuthor']			=	'1';
$INFO['MetaDesc']			=	'';
$INFO['MetaKeys']			=	'';
$INFO['MetaTitle']			=	'0';
$INFO['REPORTING']			=	'7';
$INFO['SITE_DIR']			=	'http://127.0.0.1/flowers';
$INFO['SITE_NAME']			=	'����';
$INFO['SITE_PATH']			=	''.$_SERVER["DOCUMENT_ROOT"].'';
$INFO['SMTPhost']			=	'';
$INFO['SMTPpass']			=	'';
$INFO['SMTPuser']			=	'';
$INFO['SendAuth']			=	'0';
$INFO['SendmPath']			=	'/usr/sbin/sendmail';
$INFO['Submit1']			=	'submit';
$INFO['from_name']			=	'�����';
$INFO['gzip']			=	'1';
$INFO['mail_from']			=	'hany@codexc.om';
$INFO['mailer']			=	'smtp';

?>