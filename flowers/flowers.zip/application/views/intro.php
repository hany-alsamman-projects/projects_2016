<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=windows-1256" http-equiv="Content-Type" />
<meta content="ar-sy" http-equiv="Content-Language" />
<meta name="author" content="programmed and designed by codexc.com corporation" />

<? if($this->cofings['MetaAuthor'] ==1){ ?><meta content="<?=$this->cofings['MetaKeys']?>" name="keywords" /><?}?>

<? if($this->cofings['MetaTitle'] ==1){ ?><meta content="<?=$this->cofings['MetaDesc']?>" name="description" /><?}?>

<script type="text/javascript" src="en/js/swfobject.js"></script>

<title><?=SITE_NAME?></title>


   <style type="text/css">
		@import url(en/css/en_layout.css);
	</style>
    
</head>

<body>

<div id="wrapper">

  <div id="root_board">
  
  <div id="intro" style="text-align:center"></div>
  
    <script type="text/javascript">
       swfobject.embedSWF("en/images/intro.swf", "intro", "560", "410", "9.0.0");
    </script>
      
  </div><!-- end root board -->

<div id="footer">

    <div id="by_codeXc">
    Designed, Programmed and Hosted by <a title="Designed, Programmed and Hosted by codex corporation" href="http://www.codexc.com/">Codex</a> 
    </div>

    <div id="copyright">
    Damascus - Syria <b>P.O.Box</b> :6655 <b>Email</b> : info@clima-sy.com<br />
    <b>Tel</b>. :+963 11 3719082 <b>Fax</b> : +963 11 3737948 
    </div>

</div>

</div><!-- end wrapper -->

</body>

</html>
