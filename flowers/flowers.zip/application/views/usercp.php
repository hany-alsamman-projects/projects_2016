<div>
    
    <div id="leftcol">
    
            <div class="wrap">
                <div class="box-icon">
                    <img src="images/jasmin_colors.jpg" />
                </div>
    
                <div class="box-serv">
                    <a href="index.php?action=usercp&pro=addlink"><h2>USERCP_LABEL_ADD</h2></a>
                    <p><?=$this->lang['USERCP_DESC_ADD']?></p>
                </div>
            </div>
            
            
            <div class="wrap">
                <div class="box-icon">
                    <img src="images/addlink.png" />
                </div>
    
                <div class="box-serv">
                    <a href="index.php?action=usercp&pro=linkslist" id="linkslist"><h2>USERCP_LABEL_LIST</h2></a>
                    <p><?=$this->lang['USERCP_DESC_LIST']?></p>
                </div>
            </div>
            
            
            <div class="wrap">
                <div class="box-icon">
                   <img src="images/addlink.png" />
                </div>
    
                <div class="box-serv">
                    <a href="index.php?action=usercp&pro=profile"><h2>USERCP_LABEL_PROFILE</h2></a>
                    <p><?=$this->lang['USERCP_DESC_PROFILE']?></p>
                </div>
            </div>
    </div>

</div>