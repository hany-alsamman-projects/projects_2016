<form class="fields" method="post"><!-- Forms (plain layout, cleaner) -->

							<fieldset style="margin-bottom: 15px">
								<legend><strong>����� ����</strong></legend>
                                
                                
                                
							</fieldset>
                            
                            
                            
							<fieldset style="margin-bottom: 15px">
								<legend><strong>����� ����</strong></legend>

							</fieldset>
                            
                            
                            
							<fieldset style="margin-bottom: 15px">
								<legend><strong>����� ����</strong></legend>

							</fieldset>
</form>