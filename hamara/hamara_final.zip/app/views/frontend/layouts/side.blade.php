<div class="col-sm-4">
    <div class="panel panel-new">
        <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-location-arrow"></i> Contact Details</h3>
        </div>
        <div class="panel-body">
            <address>
                <strong>Ash Shuhada, Riyadh 13241, Saudi Arabia AL HAMRA OASIS VILLAGE COMPOUND (AOVC).</strong>
                <br><br>
                <abbr title="P.O.Box">P.O.B:</abbr>  61835, RIYADH 11575<br>

                <abbr title="Telephone">T:</abbr> (966) 1 249-0440<br>
                <abbr title="Fax">F:</abbr> (966) 1 248-3628
                <br><br>
                <a href="http://www.alhamra.com.sa" target="_blank">www.alhamra.com.sa</a><br>
                <a href="mailto:aovc@alhamra.com.sa">aovc@alhamra.com.sa</a>
            </address>
            <hr>
            <!--
            <iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Riyadh+13241,+Saudi+Arabia+AL+HAMRA+OASIS+VILLAGE+COMPOUND+(AOVC).&amp;sll=24.791332,46.727905&amp;sspn=0.002092,0.002411&amp;ie=UTF8&amp;hq=&amp;hnear=&amp;ll=24.791332,46.727905&amp;spn=0.006295,0.006295&amp;t=m&amp;output=embed"></iframe>
            -->
        </div>
    </div>
</div><!--/.col-sm-4 -->
