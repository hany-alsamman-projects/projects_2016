<div id="footer">

    <div id="footer_block"><h3>مشاريع جديدة </h3>
        <p><a href="#">كمباوند</a></p>
        <p><a href="#">شقق مفروشة</a></p>
        <p><a href="#">مستشفسيات وماشريع طبية </a></p>
        <p><a href="#">فنادق ومشاريع سياحية</a></p>
        <p><a href="#">أراضي خام</a></p>
    </div>

    <div id="footer_block"><h3>مشاريع جديدة </h3>
        <p><a href="#">كمباوند</a></p>
        <p><a href="#">شقق مفروشة</a></p>
        <p><a href="#">مستشفسيات وماشريع طبية </a></p>
        <p><a href="#">فنادق ومشاريع سياحية</a></p>
        <p><a href="#">أراضي خام</a></p>
    </div>

    <div id="contact_us">
        <h3>تواصل معنا</h3>
        <form>
            <input style="width:150px" placeholder="الاسم" class="input" type="text">
            <input style="width:150px" placeholder="البريد الالكتروني" class="input mid-margin-top" type="text">
            <textarea style="width:150px; height:50px" placeholder="نص الرسالة " class="input mid-margin-top" type="text"></textarea></br>
            <button class="button glossy mid-margin-top silver-gradient" type="submit">  ارسال  </button>
        </form>
    </div>

    <div id="footer_block">
        <img src="{{asset('assets/images/home_box_img.jpg')}}" />
        <p><span>جميع الحقوق محفوظة 2013</span></p>
    </div>
</div><!-- end footer div -->
