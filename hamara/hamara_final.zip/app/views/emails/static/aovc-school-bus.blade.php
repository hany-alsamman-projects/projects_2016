Hello, you got a request about "{{ $type }}"
<br><br>

Account information:

Full Name: ({{$user->first_name}})<br>
ID#: {{$user->id}}<br>
Unit NO: {{$user->data->unit}}<br><br>

have read and understood the rules and would like to<br><br>

invite on: {{ $invite_on }}<br><br>

Information:<br>

Full Name: {{ $guest_full_name }}<br>
age: {{ $age }}<br><br>

Date: {{ $date }}<br><br>

Resident note:<br><br>

{{ $resident_note }}

<br><br>
Kind Regards
Alhamara email system