<?php

return array(


    "test" => array(
        "success" => "The :attribute must be between :min - :max.",
        "account_not_found" => "",
        "account_not_activated" => "",
    ),

);