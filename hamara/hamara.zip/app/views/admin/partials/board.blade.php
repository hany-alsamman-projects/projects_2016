
				<div class="box box-50"><!-- box 50% width -->
					<div class="boxin">
						<div class="header">
							<h3>Speed Url</h3>
						</div>
						<div class="content">
							<ul class="simple"><!-- ul.simple for simple listings of pages, categories, etc. -->
								<li class="even">
									<strong><a href="index.php?section=ChangePassword" target="_self">Change Password</a></strong>
									
								</li>
							</ul>
						</div>
					</div>
				</div><!-- Pages end -->
