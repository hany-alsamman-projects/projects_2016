@if($lang == 'ar')
@include('index_ar')
@else
@include('index_default')
@endif