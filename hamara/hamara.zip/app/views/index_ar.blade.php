<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

    <!-- Basic Page Needs
  ================================================== -->
    <meta charset="utf-8">
    <title>بوابة المصادر</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Mobile Specific Metas
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
  ================================================== -->
    {{ HTML::style('assets/css/base.css')}}
    {{ HTML::style('assets/css/skeleton.css')}}
    {{ HTML::style('assets/css/layout_ar.css')}}
    {{ HTML::style('assets/css/jquery.bxslider.css')}}

    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Favicons
    ================================================== -->
    <link rel="shortcut icon" href="{{asset('assets/images/favicon.ico')}}">
    <link rel="apple-touch-icon" href="{{asset('assets/images/apple-touch-icon.png')}}')}}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{asset('assets/images/apple-touch-icon-72x72.png')}}')}}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{asset('assets/images/apple-touch-icon-114x114.png')}}')}}">

    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,400italic,600italic' rel='stylesheet' type='text/css'>

</head>
<body>

<header>
    <div class="container">
        <div class="logo">
            <img src="{{asset('assets/images/logo.png')}}"/>
        </div>
        <div class="login eleven columns">
            @if(!Sentry::check())
            <form method="post" action="{{ route('signin') }}">
                <!-- CSRF Token -->
                <input type="hidden" name="_token" value="{{ csrf_token() }}" />

                <span>الصحف الإلكترونية</span>
                <input type="text" name="email" value="{{ Input::old('email') }}" placeholder="اسم المستخدم"> <input type="password" name="password" placeholder="كلمة السر">
                <button class="login_btn_blue" type="submit">دخول</button>
                <a class="login_btn_orange" href="#">تسجيل</a>
            </form>
            @else
            Welcome <span>{{ Sentry::getUser()->first_name }}</span> <a class="login_btn_orange" href="{{ URL::to('auth/logout') }}">SignOut</a>
            @endif
        </div>
    </div>
    <div class="container">
        <div id="intro-top">
            <nav class="seven columns">
                <div class="menu_wrapper">
                    <ul data-breakpoint="800" class="menu_list">
                        @foreach(HomeController::MainPages('ar') as $page)
                        @if($page->slug != 'home-ar')
                        <li><a href="{{ URL::to("".Request::segment(1)."/page/$page->slug") }}">{{$page->title}}</a>
                            @endif
                            @if(HomeController::SubPages($page->id))
                            <ul>
                                @foreach(HomeController::SubPages($page->id) as $subpage)
                                <li><a href="{{ URL::to("".Request::segment(1)."/page/$subpage->slug") }}">{{$subpage->title}}</a></li>
                                @endforeach
                            </ul>
                        </li>
                        @else
                        </li>
                        @endif
                        @endforeach
                    </ul>
                </div>
            </nav>
            <div id="slider-top"></div>
        </div>
        <span id="slider-prev"></span>
        <div id="intro">
            <ul class="bxslider">
                <li><img src="{{asset('assets/images/slide6.jpg')}}"/></li>
                <li><img src="{{asset('assets/images/slide2.jpg')}}"/></li>
                <li><img src="{{asset('assets/images/slide3.jpg')}}"/></li>
                <li><img src="{{asset('assets/images/slide4.jpg')}}"/></li>
                <li><img src="{{asset('assets/images/slide5.jpg')}}"/></li>
                <li><img src="{{asset('assets/images/slide1.jpg')}}"/></li>
            </ul>
        </div>
        <span id="slider-next"></span>
        <div class="intro_txt">
            <p>
                مؤسسة <span class="intro_bold">بوابة المصادر </span> .. نافذتك المعلوماتية المتكاملة لتوفير كافة المصادر بأفضل خدمة وأفضل سرعة لتحقيق متطلباتكم            </p>
        </div>
    </div>
</header>

@if( Request::segment(2) == false)
<section id="contents">
    <div class="container">
        <div class="main_page">
            {{ Page::where('static', 1)->where('slug', 'home-ar')->first()->content }}
        </div>
        <!-- main page -->
    </div>
</section>

@elseif( HomeController::checkStaticPage(Request::segment(3)) )

@include('static.'.Request::segment(3))

@else
<section id="contents">
    <div class="container">
        <div class="main_page">
            @if($search_mode == true)
            @include('static.search')
            @else
            {{$getPage->content}}
            @endif
        </div>
        <!-- main page -->
    </div>
</section>
@endif

<footer>
    <div class='container'>
        <div>
            <p>جميع الحقوق محفوظة لبوابة المصدر © 2009 - 2014 <br> تنفيذ <a href="http://vip4it.com" target="_blank">المشاريع الافتراضية المتكاملة</a></p>
        </div>
    </div>
</footer>

<script src="{{asset('assets/js/jquery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('assets/js/jquery.bxslider.min.js')}}" type="text/javascript"></script>
<script src="{{asset('assets/js/jquery.flexnav.js')}}" type="text/javascript"></script>
<script>
    $(document).ready(function(){

        $('.bxslider').bxSlider({
            auto: true,
            mode: 'fade',
            pager: false,
            nextSelector: '#slider-next',
            prevSelector: '#slider-prev',
            nextText: '<img src="{{asset('assets/images/arrow_right.png')}}"/>',
            prevText: '<img src="{{asset('assets/images/arrow_left.png')}}"/>'
    });

    $(".menu_list").hover(
        function() { $(".sub").slideToggle(400); },
        function() { $(".sub").hide(); }
    );

    $(".menu_list").flexNav();
    });
</script>
</body>
</html>