Hello,<br>

You have been contacted from your contact form, their
additional message is as follows.<br><br>

{{ $content }}