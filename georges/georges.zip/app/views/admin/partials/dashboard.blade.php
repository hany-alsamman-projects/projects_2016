<div class="row-fluid page-head">
    <h2 class="page-title"><i class="fontello-icon-monitor"></i> Administrators <small>Dashboard</small></h2>
    <p class="pagedesc">Administrators - Dashboard </p>
    <div class="page-bar">
        <div class="btn-toolbar"> </div>
    </div>
</div>
<!-- // page head -->


<div id="page-content" class="page-content">

<section>
    <div class="row-fluid margin-top20">
        <div class="span12 well well-black">
            <div class="row-fluid">
                <div class="span6 grider">

                    Welcome

                </div>

            </div>
        </div>
        <!-- // column -->

    </div>
    <!-- // Example row -->
</section>

</div>