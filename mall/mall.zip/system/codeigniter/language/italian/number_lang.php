<?php
/* Translation made By Alessandro Piconi: all update on invernomuto.net */
/* Date 18/09/2009 */
/* Modified by Nicola Tudino */
/* Date 04/11/2010 */

$lang['terabyte_abbr'] = "TB";
$lang['gigabyte_abbr'] = "GB";
$lang['megabyte_abbr'] = "MB";
$lang['kilobyte_abbr'] = "KB";
$lang['bytes'] = "Bytes";

/* End of file number_lang.php */
/* Location: ./system/language/italian/number_lang.php */