<?php
$lang['terabyte_abbr'] = 'Тб';
$lang['gigabyte_abbr'] = 'Гб';
$lang['megabyte_abbr'] = 'Мб';
$lang['kilobyte_abbr'] = 'Кб';
$lang['bytes'] = 'Байт';