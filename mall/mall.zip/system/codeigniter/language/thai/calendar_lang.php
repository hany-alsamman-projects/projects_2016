<?php
/**translate by mr.v automatic
 *www.okvee.net
 */

$lang['cal_su']			= "อา";
$lang['cal_mo'] 		= "จ";
$lang['cal_tu'] 		= "อ";
$lang['cal_we'] 		= "พ";
$lang['cal_th'] 		= "พฤ";
$lang['cal_fr'] 		= "ศ";
$lang['cal_sa'] 		= "ส";
$lang['cal_sun'] 		= "อาทิตย์";
$lang['cal_mon'] 		= "จันทร์";
$lang['cal_tue'] 		= "อังคาร";
$lang['cal_wed'] 		= "พุธ";
$lang['cal_thu'] 		= "พฤหัสบดี";
$lang['cal_fri'] 		= "ศุกร์";
$lang['cal_sat'] 		= "เสาร์";
$lang['cal_sunday']		= "วันอาทิตย์";
$lang['cal_monday']		= "วันจันทร์";
$lang['cal_tuesday']	= "วันอังคาร";
$lang['cal_wednesday']	= "วันพุธ";
$lang['cal_thursday']	= "วันพฤหัสบดี";
$lang['cal_friday']		= "วันศุกร์";
$lang['cal_saturday']	= "วันเสาร์";
$lang['cal_jan'] 		= "ม.ค.";
$lang['cal_feb'] 		= "ก.พ.";
$lang['cal_mar'] 		= "มี.ค.";
$lang['cal_apr'] 		= "เม.ย.";
$lang['cal_may'] 		= "พ.ค.";
$lang['cal_jun'] 		= "มิ.ย.";
$lang['cal_jul'] 		= "ก.ค.";
$lang['cal_aug'] 		= "ส.ค.";
$lang['cal_sep'] 		= "ก.ย.";
$lang['cal_oct'] 		= "ต.ค.";
$lang['cal_nov'] 		= "พ.ย.";
$lang['cal_dec'] 		= "ธ.ค.";
$lang['cal_january'] 	= "มกราคม";
$lang['cal_february'] 	= "กุมภาพันธ์";
$lang['cal_march'] 		= "มีนาคม";
$lang['cal_april']		= "เมษายน";
$lang['cal_mayl'] 		= "พฤษภาคม";
$lang['cal_june'] 		= "มิถุนายน";
$lang['cal_july'] 		= "กรกฎาคม";
$lang['cal_august']		= "สิงหาคม";
$lang['cal_september']	= "กันยายน";
$lang['cal_october'] 	= "ตุลาคม";
$lang['cal_november']	= "พฤศจิกายน";
$lang['cal_december'] 	= "ธันวาคม";


/* End of file calendar_lang.php */
/* Location: ./system/language/english/calendar_lang.php */