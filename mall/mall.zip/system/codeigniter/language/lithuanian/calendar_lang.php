<?php

$lang['cal_su']			= "S";
$lang['cal_mo']			= "P";
$lang['cal_tu']			= "A";
$lang['cal_we']			= "T";
$lang['cal_th']			= "K";
$lang['cal_fr']			= "P";
$lang['cal_sa']			= "Š";
$lang['cal_sun']		= "Sek";
$lang['cal_mon']		= "Pirm";
$lang['cal_tue']		= "Antr";
$lang['cal_wed']		= "Treč";
$lang['cal_thu']		= "Ket";
$lang['cal_fri']		= "Penk";
$lang['cal_sat']		= "Šešt";
$lang['cal_sunday']		= "Sekmadienis";
$lang['cal_monday']		= "Pirmadienis";
$lang['cal_tuesday']	= "Antradienis";
$lang['cal_wednesday']	= "Trečiadienis";
$lang['cal_thursday']	= "Ketvirtadienis";
$lang['cal_friday']		= "Penktadienis";
$lang['cal_saturday']	= "Šeštadienis";
$lang['cal_jan']		= "01";
$lang['cal_feb']		= "02";
$lang['cal_mar']		= "03";
$lang['cal_apr']		= "04";
$lang['cal_may']		= "05";
$lang['cal_jun']		= "06";
$lang['cal_jul']		= "07";
$lang['cal_aug']		= "08";
$lang['cal_sep']		= "09";
$lang['cal_oct']		= "10";
$lang['cal_nov']		= "11";
$lang['cal_dec']		= "12";
$lang['cal_january']	= "Sausis";
$lang['cal_february']	= "Vasaris";
$lang['cal_march']		= "Kovas";
$lang['cal_april']		= "Balandis";
$lang['cal_mayl']		= "Gegužė";
$lang['cal_june']		= "Birželis";
$lang['cal_july']		= "Liepa";
$lang['cal_august']		= "Rugpjūtis";
$lang['cal_september']	= "Rugsėjis";
$lang['cal_october']	= "Spalis";
$lang['cal_november']	= "Lapkritis";
$lang['cal_december']	= "Gruodis";


/* End of file calendar_lang.php */
/* Location: ./system/language/english/calendar_lang.php */