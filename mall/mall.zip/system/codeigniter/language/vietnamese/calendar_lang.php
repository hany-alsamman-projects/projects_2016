<?php

$lang['cal_su']			= "CN";
$lang['cal_mo']			= "T2";
$lang['cal_tu']			= "T3";
$lang['cal_we']			= "T4";
$lang['cal_th']			= "T5";
$lang['cal_fr']			= "T6";
$lang['cal_sa']			= "T7";
$lang['cal_sun']		= "C.N";
$lang['cal_mon']		= "T.2";
$lang['cal_tue']		= "T.3";
$lang['cal_wed']		= "T.4";
$lang['cal_thu']		= "T.5";
$lang['cal_fri']		= "T.6";
$lang['cal_sat']		= "T.7";
$lang['cal_sunday']		= "Chủ nhật";
$lang['cal_monday']		= "Thứ 2";
$lang['cal_tuesday']	= "Thứ 3";
$lang['cal_wednesday']	= "Thứ 4";
$lang['cal_thursday']	= "Thứ 5";
$lang['cal_friday']		= "Thứ 6";
$lang['cal_saturday']	= "Thứ 7";
$lang['cal_jan']		= "Th1";
$lang['cal_feb']		= "Th2";
$lang['cal_mar']		= "Th3";
$lang['cal_apr']		= "Th4";
$lang['cal_may']		= "Th5";
$lang['cal_jun']		= "Th6";
$lang['cal_jul']		= "Th7";
$lang['cal_aug']		= "Th8";
$lang['cal_sep']		= "Th9";
$lang['cal_oct']		= "Th10";
$lang['cal_nov']		= "Th11";
$lang['cal_dec']		= "Th12";
$lang['cal_january']	= "Tháng 1";
$lang['cal_february']	= "Tháng 2";
$lang['cal_march']		= "Tháng 3";
$lang['cal_april']		= "Tháng 4";
$lang['cal_mayl']		= "Tháng 5";
$lang['cal_june']		= "Tháng 6";
$lang['cal_july']		= "Tháng 7";
$lang['cal_august']		= "Tháng 8";
$lang['cal_september']	= "Tháng 9";
$lang['cal_october']	= "Tháng 10";
$lang['cal_november']	= "Tháng 11";
$lang['cal_december']	= "Tháng 12";


/* End of file calendar_lang.php */
/* Location: ./system/language/vietnamese/calendar_lang.php */