<?php

$lang['terabyte_abbr'] = "Tt";
$lang['gigabyte_abbr'] = "Gt";
$lang['megabyte_abbr'] = "Mt";
$lang['kilobyte_abbr'] = "Kt";
$lang['bytes'] = "Tavua";

/* End of file number_lang.php */
/* Location: ./system/language/finnish/number_lang.php */