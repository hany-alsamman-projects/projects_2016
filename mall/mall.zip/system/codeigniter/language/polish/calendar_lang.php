<?php

$lang['cal_su']			= "Nie";
$lang['cal_mo'] 		= "Pon";
$lang['cal_tu'] 		= "Wto";
$lang['cal_we'] 		= "Śr";
$lang['cal_th'] 		= "Czw";
$lang['cal_fr'] 		= "Pt";
$lang['cal_sa'] 		= "So";
$lang['cal_sun'] 		= "Nie";
$lang['cal_mon'] 		= "Pon";
$lang['cal_tue'] 		= "Wto";
$lang['cal_wed'] 		= "Śr";
$lang['cal_thu'] 		= "Czw";
$lang['cal_fri'] 		= "Pt";
$lang['cal_sat'] 		= "So";
$lang['cal_sunday']		= "Niedziela";
$lang['cal_monday']		= "Poniedziałek";
$lang['cal_tuesday']            = "Wtorek";
$lang['cal_wednesday']          = "Środa";
$lang['cal_thursday']           = "Czwartek";
$lang['cal_friday']		= "Piątek";
$lang['cal_saturday']           = "Sobota";
$lang['cal_jan'] 		= "Styczeń";
$lang['cal_feb'] 		= "Luty";
$lang['cal_mar'] 		= "Marzec";
$lang['cal_apr'] 		= "Kwiecień";
$lang['cal_may'] 		= "Maj";
$lang['cal_jun'] 		= "Czerwiec";
$lang['cal_jul'] 		= "Lipiec";
$lang['cal_aug'] 		= "Sierpień";
$lang['cal_sep'] 		= "Wrzesień";
$lang['cal_oct'] 		= "Październik";
$lang['cal_nov'] 		= "Listopad";
$lang['cal_dec'] 		= "Grudzień";
$lang['cal_january'] 	= "Styczeń";
$lang['cal_february'] 	= "Luty";
$lang['cal_march'] 		= "Marzec";
$lang['cal_april']		= "Kwiecień";
$lang['cal_mayl'] 		= "Maj";
$lang['cal_june'] 		= "Czerwiec";
$lang['cal_july'] 		= "Lipiec";
$lang['cal_august']		= "Sierpień";
$lang['cal_september']	= "Wrzesień";
$lang['cal_october'] 	= "Październik";
$lang['cal_november']	= "Listopad";
$lang['cal_december'] 	= "Grudzień";


/* End of file calendar_lang.php */
/* Location: ./system/language/english/calendar_lang.php */