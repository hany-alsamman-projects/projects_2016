<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-12-27 00:36:32 --> Severity: Warning  --> session_start(): open(/var/lib/php5/sess_4ijhdm5tggb0t7tmjec47vkl06, O_RDWR) failed: No such file or directory (2) /home/hany/public_html/vt/system/cms/hooks/pick_language.php 30
ERROR - 2012-12-27 00:37:32 --> Severity: Warning  --> session_start(): open(/var/lib/php5/sess_4ijhdm5tggb0t7tmjec47vkl06, O_RDWR) failed: No such file or directory (2) /home/hany/public_html/vt/system/cms/hooks/pick_language.php 30
