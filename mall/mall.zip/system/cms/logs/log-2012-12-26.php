<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-12-26 00:01:59 --> Severity: Notice  --> Undefined index: id /home/hany/public_html/vt/system/cms/modules/pages/plugin.php 48
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 298
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Creating default object from empty value /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$slug /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$layout_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$css /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$js /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_description /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$is_home /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$status /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$parent_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 390
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$chunks /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 298
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Creating default object from empty value /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$slug /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$layout_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$css /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$js /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_description /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$is_home /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$status /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$parent_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 390
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$chunks /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 298
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Creating default object from empty value /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$slug /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$layout_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$css /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$js /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_description /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$is_home /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$status /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$parent_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 390
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$chunks /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 298
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Creating default object from empty value /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$slug /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$layout_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$css /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$js /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_description /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$is_home /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$status /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$parent_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 390
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$chunks /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 298
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Creating default object from empty value /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$slug /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$layout_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$css /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$js /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_description /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$is_home /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$status /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$parent_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 390
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$chunks /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 298
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Creating default object from empty value /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$slug /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$layout_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$css /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$js /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_description /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$is_home /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$status /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$parent_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 390
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$chunks /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 298
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Creating default object from empty value /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$slug /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$layout_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$css /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$js /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_description /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$is_home /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$status /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$parent_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 390
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$chunks /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 298
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Creating default object from empty value /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 306
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$slug /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$layout_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$css /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$js /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_title /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$meta_description /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$is_home /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$status /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 386
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$parent_id /home/hany/public_html/vt/system/cms/modules/pages/controllers/admin.php 390
ERROR - 2012-12-26 01:20:52 --> Severity: Notice  --> Undefined property: stdClass::$chunks /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/hany/public_html/vt/system/cms/modules/pages/views/admin/form.php 74
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
ERROR - 2012-12-26 01:20:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/system/codeigniter/core/Exceptions.php:186) /home/hany/public_html/vt/system/codeigniter/core/Output.php 368
