<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-01-06 22:19:34 --> Query error: Data too long for column 'body' at row 1
ERROR - 2013-01-06 22:22:31 --> Severity: Notice  --> Array to string conversion /home/hany/public_html/mall/system/cms/libraries/Lex/Parser.php 181
