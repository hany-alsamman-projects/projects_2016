<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-12-25 23:10:27 --> Severity: Warning  --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/hany/public_html/vt/index.php:29) /home/hany/public_html/vt/system/cms/hooks/pick_language.php 30
ERROR - 2012-12-25 23:10:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:29) /home/hany/public_html/vt/system/codeigniter/libraries/Session.php 675
ERROR - 2012-12-25 23:58:26 --> Query error: Truncated incorrect DOUBLE value: '9.html'
ERROR - 2012-12-25 23:58:29 --> Query error: Truncated incorrect DOUBLE value: '9.html'
