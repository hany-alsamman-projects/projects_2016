<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-12-16 09:51:17 --> Severity: Warning  --> fsockopen() [<a href='function.fsockopen'>function.fsockopen</a>]: unable to connect to ssl://www.pyrocms.com:443 (Unable to find the socket transport &quot;ssl&quot; - did you forget to enable it when you configured PHP?) C:\xampp\htdocs\vt\system\cms\libraries\Simplepie.php 4393
ERROR - 2012-12-16 09:52:05 --> Severity: Warning  --> fsockopen() [<a href='function.fsockopen'>function.fsockopen</a>]: unable to connect to ssl://www.pyrocms.com:443 (Unable to find the socket transport &quot;ssl&quot; - did you forget to enable it when you configured PHP?) C:\xampp\htdocs\vt\system\cms\libraries\Simplepie.php 4393
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:53:30 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:53:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:53:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:53:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:53:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:53:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:53:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:54:10 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:54:11 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:54:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:55:37 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:55:38 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:55:39 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:39 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:55:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:55:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:56:18 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:56:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:56:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:56:19 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:56:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:58:55 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:58:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:58:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:58:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:59:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:59:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 09:59:45 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 09:59:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 10:01:16 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 10:01:17 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 10:01:43 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 298
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 306
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$slug C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$layout_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$css C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$js C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_keywords C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$rss_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$comments_enabled C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$is_home C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$strict_uri C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 386
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\vt\system\cms\modules\pages\controllers\admin.php 390
ERROR - 2012-12-16 10:01:44 --> Severity: Notice  --> Undefined property: stdClass::$chunks C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vt\system\cms\modules\pages\views\admin\form.php 74
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:01:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vt\system\codeigniter\core\Exceptions.php:186) C:\xampp\htdocs\vt\system\codeigniter\core\Output.php 368
ERROR - 2012-12-16 10:27:52 --> Severity: Warning  --> fsockopen() [<a href='function.fsockopen'>function.fsockopen</a>]: unable to connect to ssl://www.pyrocms.com:443 (Unable to find the socket transport &quot;ssl&quot; - did you forget to enable it when you configured PHP?) C:\xampp\htdocs\vt\system\cms\libraries\Simplepie.php 4393
ERROR - 2012-12-16 11:42:22 --> Severity: Warning  --> fsockopen() [<a href='function.fsockopen'>function.fsockopen</a>]: unable to connect to ssl://www.pyrocms.com:443 (Unable to find the socket transport &quot;ssl&quot; - did you forget to enable it when you configured PHP?) C:\xampp\htdocs\vt\system\cms\libraries\Simplepie.php 4393
