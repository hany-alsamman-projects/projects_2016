<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-12-13 01:50:08 --> Severity: Warning  --> fsockopen() [<a href='function.fsockopen'>function.fsockopen</a>]: unable to connect to ssl://www.pyrocms.com:443 (Unable to find the socket transport &quot;ssl&quot; - did you forget to enable it when you configured PHP?) C:\xampp\htdocs\vt\system\cms\libraries\Simplepie.php 4393
ERROR - 2012-12-13 01:52:42 --> Severity: Warning  --> fsockopen() [<a href='function.fsockopen'>function.fsockopen</a>]: unable to connect to ssl://www.pyrocms.com:443 (Unable to find the socket transport &quot;ssl&quot; - did you forget to enable it when you configured PHP?) C:\xampp\htdocs\vt\system\cms\libraries\Simplepie.php 4393
