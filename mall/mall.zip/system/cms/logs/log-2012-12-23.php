<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-12-23 02:23:42 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:23:42 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:23:42 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:23:42 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:23:43 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:23:43 --> Unable to connect to the database
ERROR - 2012-12-23 02:23:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:30:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:30:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:30:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:30:24 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:30:24 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:30:24 --> Unable to connect to the database
ERROR - 2012-12-23 02:30:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:30:28 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:30:28 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:30:28 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:30:28 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:30:28 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:30:28 --> Unable to connect to the database
ERROR - 2012-12-23 02:30:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:31:53 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:31:53 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:31:53 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:31:53 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:31:53 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:31:53 --> Unable to connect to the database
ERROR - 2012-12-23 02:31:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:31:59 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:31:59 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:31:59 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:31:59 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:31:59 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:31:59 --> Unable to connect to the database
ERROR - 2012-12-23 02:31:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:39:25 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:39:25 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:39:25 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:39:25 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:39:25 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:39:25 --> Unable to connect to the database
ERROR - 2012-12-23 02:39:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:42:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:42:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:42:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:42:24 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:42:24 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:42:24 --> Unable to connect to the database
ERROR - 2012-12-23 02:42:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:42:29 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:42:29 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:42:29 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:42:29 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:42:29 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:42:29 --> Unable to connect to the database
ERROR - 2012-12-23 02:42:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:42:35 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:42:35 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:42:35 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:42:35 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:42:35 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:42:35 --> Unable to connect to the database
ERROR - 2012-12-23 02:42:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:44:02 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:44:02 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:44:02 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:44:02 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:44:02 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:44:02 --> Unable to connect to the database
ERROR - 2012-12-23 02:44:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:45:07 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:45:07 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:45:07 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:45:07 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:45:07 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:45:07 --> Unable to connect to the database
ERROR - 2012-12-23 02:45:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:45:09 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:45:09 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:45:09 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:45:09 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:45:09 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:45:09 --> Unable to connect to the database
ERROR - 2012-12-23 02:45:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:47:03 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:47:03 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:47:03 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:47:03 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:47:03 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:47:03 --> Unable to connect to the database
ERROR - 2012-12-23 02:47:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 02:47:34 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 02:47:34 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:47:34 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 02:47:34 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 02:47:34 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 02:47:34 --> Unable to connect to the database
ERROR - 2012-12-23 02:47:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:07:15 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 03:07:15 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:07:15 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:07:15 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 03:07:15 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:07:15 --> Unable to connect to the database
ERROR - 2012-12-23 03:07:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:09:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 03:09:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:09:24 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:09:24 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 03:09:24 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:09:24 --> Unable to connect to the database
ERROR - 2012-12-23 03:09:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:16:44 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 03:16:44 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:16:44 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:16:44 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 03:16:44 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:16:44 --> Unable to connect to the database
ERROR - 2012-12-23 03:16:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:16:47 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 03:16:47 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:16:47 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:16:47 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 03:16:47 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:16:47 --> Unable to connect to the database
ERROR - 2012-12-23 03:16:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:16:49 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 03:16:49 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:16:49 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:16:49 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 03:16:49 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:16:49 --> Unable to connect to the database
ERROR - 2012-12-23 03:16:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:17:02 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 03:17:02 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:17:02 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:17:02 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 03:17:02 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:17:02 --> Unable to connect to the database
ERROR - 2012-12-23 03:17:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:17:32 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 03:17:32 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:17:32 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:17:32 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 03:17:32 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:17:32 --> Unable to connect to the database
ERROR - 2012-12-23 03:17:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:21:13 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 276
ERROR - 2012-12-23 03:21:13 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:21:13 --> Severity: Notice  --> Undefined index: SERVER_NAME /home/hany/public_html/vt/system/cms/config/config.php 277
ERROR - 2012-12-23 03:21:13 --> Severity: Notice  --> Undefined index: REQUEST_URI /home/hany/public_html/vt/system/cms/config/config.php 305
ERROR - 2012-12-23 03:21:13 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:21:13 --> Unable to connect to the database
ERROR - 2012-12-23 03:21:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/hany/public_html/vt/index.php:229) /home/hany/public_html/vt/system/codeigniter/core/Common.php 462
ERROR - 2012-12-23 03:28:45 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-23 03:28:45 --> Unable to connect to the database
