<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-12-22 04:34:06 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-22 04:34:06 --> Unable to connect to the database
ERROR - 2012-12-22 04:34:07 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-22 04:34:07 --> Unable to connect to the database
ERROR - 2012-12-22 04:36:11 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: NO) /home/hany/public_html/vt/system/codeigniter/database/drivers/mysql/mysql_driver.php 84
ERROR - 2012-12-22 04:36:11 --> Unable to connect to the database
