<div class="blog_page container">
    <div class="row-fluid">

        <div class="span4">
            <div class="post">
                <img src="images/gallery/help_desk.jpg">
                <div class="post_info">
                    <div class="inner">
                        <h4><a href="http://nitaqaty.com/?/tickets/new/">هل تحتاج مساعدة؟</a></h4>
                        <p>اذا كان لديك اي استفسار او مساعدة موظفونا في الدعم الفني جاهزين لتلقي طلباتك</p>
                        <a style="height: 60px; margin: 10px auto" target="_blank" class="main-btn load-more" href="http://nitaqaty.com/?/tickets/new/">
                            <span class="icon-headphones"></span> استفسار
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="span4">
            <div class="post">
                <img src="images/gallery/your_way.jpg">
                <div class="post_info">
                    <div class="inner">
                        <h4><a href="index.php?action=usercp&pro=linkslist" id="pre_addlink">ابدء موقعك الآن</a></h4>
                        <p>اذا كنت قد استلمت كود التفعيل فأن الخطوة الوحيده لتبدأ موقعك هي باضافة موقعك لإنشاءه الآن</p>

                        <a style="height: 60px; margin: 10px auto" class="main-btn load-more" href="index.php?action=usercp&pro=linkslist" id="pre_addlink">
                            <span class="icon-dashboard"></span> اضغط هنا
                        </a>
                    </div>
                </div>
            </div>
        </div>


        <div class="span4">
            <div class="post">
                <img src="images/gallery/2.jpg">
                <div class="post_info">
                    <div class="inner">
                        <h4><a href="index.php?action=usercp&pro=linkslist" id="linkslist">قائمة مواقعي</a></h4>
                        <p>
هنا سوف تجد قائمة المواقع الخاصة بك المبنية عن طريق خدمة نطاق ويكس
                      

                            <a style="height: 60px; margin: 10px auto" class="main-btn load-more"  href="index.php?action=usercp&pro=linkslist" id="linkslist">
                                <span class="icon-desktop"></span> عرض المواقع
                            </a>
                        </p>

                    </div>
                </div>
            </div>
        </div>


    </div>
</div>
