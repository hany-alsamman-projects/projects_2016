<div class="box box-35"><!-- Main menu -->

    <div class="boxin">
		<div class="header">
			<h3>Management Cities</h3>
		</div>
		<div class="content">
			<ul class="simple">
				<li class="even">
					<strong><a href="index.php?section=Addcity" target="_self">Add City</a></strong>
				</li>
				<li>
					<strong><a href="index.php?section=Showcities">Show Cities</a></strong>
				</li>                              
			</ul>
		</div>
	</div><!-- Management Departments -->



	<div style="margin-top: 25px;" class="boxin">
		<div class="header">
			<h3>Managment Members</h3>
		</div>
		<div class="content">
			<ul class="simple">
				<li class="even">
					<strong><a href="index.php?section=ShowMembers">Show Members</a></strong>
				</li>
				<li>
					<strong><a href="index.php?section=ShowMembers&think=waiting">Waiting Members</a></strong>
				</li>
				<li>
					<strong><a href="index.php?section=AddMember">Add Member</a></strong>
				</li>
			</ul>
		</div>
	</div><!-- Managment Links -->
    
</div><!-- end Main menu -->
