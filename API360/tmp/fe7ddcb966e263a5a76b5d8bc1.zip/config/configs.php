<?php
$INFO['MetaAuthor']			=	'1';
$INFO['MetaDesc']			=	'';
$INFO['MetaKeys']			=	'';
$INFO['MetaTitle']			=	'1';
$INFO['REPORTING']			=	'7';
$INFO['SITE_DIR']			=	'http://127.0.0.1/API360';
$INFO['SITE_NAME']			=	'Links';
$INFO['SITE_PATH']			=	''.$_SERVER["DOCUMENT_ROOT"].'/API360';
$INFO['SMTPhost']			=	'';
$INFO['SMTPpass']			=	'';
$INFO['SMTPuser']			=	'';
$INFO['SendAuth']			=	'0';
$INFO['SendmPath']			=	'/usr/sbin/sendmail';
$INFO['Submit1']			=	'submit';
$INFO['from_name']			=	'API360';
$INFO['gzip']			=	'1';
$INFO['mail_from']			=	'info@CODEXC.COM';
$INFO['mailer']			=	'smtp';

define("SITE_URL", "http://127.0.0.1/API360");
define("SITE_NAME", "VT API");
define("SITE_PATH", $_SERVER["DOCUMENT_ROOT"] . "/API360");
define ('DEVELOPMENT_ENVIRONMENT',true); 
define ('COMPRESS_OUTPUT',false); 
define("DEFAULT_LANG", "en");

?>
