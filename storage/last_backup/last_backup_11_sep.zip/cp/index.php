<? include("inc/header.php")?>
<div class="titles">Control Panel</div>
<? include("inc/footer.php")?>

