<?
define("_align","left");
define("_Xalign","right");
define("_en","English");
define("_ar","Arabic");
define("_xlang","عربي");
define("_lg","en");
define("_xlg","ar");

define("_add","ADD");
define("_edit","Edit");
define("_delete","Delet");
define("_delete_photo","Delete photo");
define("_delete_selected","Delete selected");
define("_save","Save");
define("_cancel","Cancel");
define("_close","Close");
define("_yes","Yes");
define("_no","No");
define("_next","Next");
define("_priv","Previous");
define("_up","Up");
define("_down","Down");
define("_sub_menu","Submenu");

define("_ex_list","List of Exhibitions");
define("_menu","Menus");
define("_t_pages","Text Pages");
define("_t_spons","Types of Sponsors");
define("_add_spons","Add Sponsor");
define("_edit_spons","Edit Sponsor");
define("_spons","Sponsors");
define("_spon","Sponsor");
define("_EandC","Exhibitions & Conferences");
define("_albums","Photo Albums");
define("_modules","Modules");
define("_name","Name");
define("_lang","Language");
define("_link","Link");
define("_add_page","Add page");
define("_edit_page","Edit page");
define("_title","Title");
define("_content","Content");
define("_back","Back");
define("_en_type","Type in English");
define("_ar_type","Type in Arabic");
define("_en_name","Name in English");
define("_ar_name","Name in Arabic");
define("_en_summary","Summary in English");
define("_ar_summary","Summary in Arabic");
define("_en_content","Content in English");
define("_ar_content","Content in Arabic");
define("_en_title","Title in English");
define("_ar_title","Title in Arabic");
define("_photo","Photo");
define("_photos","Photos");
define("_logo","Logo");
define("_year","Year");
define("_sDate","Satrt date");
define("_eDate","End date");
define("_from","From");
define("_to","To");
define("_summary","Summary");
define("_mInfo","Main information");
define("_details","Details");
define("_albums","Albums");
define("_files","Files");
define("_file","File");
define("_reg","Registration");
define("_type","Type");
define("_expo","Exhibition");
define("_expos","Exhibitions");
define("_en_link","Link in English");
define("_ar_link","Link in Arabic");
define("_act","Active");
define("_en_des","Description in English");
define("_ar_des","Description in Arabic");
define("_backToEX","Back to Exhibition");
define("_ex_type","Back to Exhibition");




/////msg
define("_del_rec","do you want delete the record ?");
define("_del_opr","do you want complete delete operation ?");
define("_del_sel_rec","do you want delete the selected records ?");
define("_sel1rec","you must  select one record at least");

define("_logout","Logout");
?>