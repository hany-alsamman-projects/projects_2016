<? 
include('inc/start.php');
login('login');
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Storage</title>
<link href="inc/<?=$lg?>_style.css" rel="stylesheet" type="text/css" />
<link href="inc/style.css" rel="stylesheet" type="text/css" />
<link href= "../library/jquery/css/custom-theme/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css"/>
<script src="../library/jquery/jquery-1.6.3.min.js"></script>
<script src="../library/jquery/js/jquery-ui-1.8.16.custom.min.js"></script>
<script src="../library/jquery/development-bundle/ui/jquery.ui.datepicker.js"></script>
<script src="/storage/cp/inc/funsJS.js"></script>
</head>
<body>
<table width="1000" height="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="cpTable">
<tr>
<td valign="top" bgcolor="#000000" align="center">
<? include("inc/menu.php")?></td>
<td width="776"  valign="top" bgcolor="#FFFFFF">
<div style="margin:10px">
<div style="margin:10px">
