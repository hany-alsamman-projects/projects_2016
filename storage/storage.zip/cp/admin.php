<? include("inc/header2.php")?>
<div class="titles">Admin Control Panel</div>
<? include("inc/footer.php")?>
