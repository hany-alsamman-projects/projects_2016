<?php

/**
 * api.php
 *
 * @author Hany alsamman < hany.alsamman@gmail.com >
 * @pattern private
 * @access TEAM
 */

class API extends CONTROLLERS
{
	
	var $ACTION;
	var $CODE;


    /**
     * USERCP::__construct()
     * 
     * @return
     */
    public function __construct()
    {
        global $INFO;
		
	$this->ACTION = $_GET['action'];
        
        $this->cofings = $INFO;
        
	$this->smarty = $smarty;

    }


    public function GET_BOOKS(){

        ## account "ID"
        $type_app = trim($_GET['type_app']);

        $result = @mysql_query("SELECT book_name,book_image, book_extra AS book_dl, `book_price`, `book_dir`, `store_id`, `publish_date`, `added_by` * FROM `books` WHERE `book_type` = '{$type_app}'");
	

        if( !mysql_num_rows($result) ){
            FUNCTIONS::xml_msg('0');
            exit();
        }

        // The names of the root node and the node that will contain a row
        $root_element = "response";


        // Create the DOMDocument and the root node
        $dom = new DOMDocument('1.0', 'utf-8');
        $rootNode = $dom->appendChild($dom->createElement($root_element));


        // Loop the DB results
        while ($row = mysql_fetch_assoc($result)) {
            $row_element_s1 = "books";
            // Create a row node
            $rowNode = $rootNode->appendChild($dom->createElement($row_element_s1));
            // Loop the columns
            foreach ($row as $col => $val) {
                // Create the column node and add the value in a CDATA section
                $rowNode->appendChild($dom->createElement($col))->appendChild($dom->createCDATASection($val));
            }
        }

        header("Content-type: text/xml; charset=utf-8");
        // Output as string
        echo $dom->saveXML();
    }


    /**
     * USERCP::__destruct()
     * 
     * @return
     */
    public function __destruct()
    {
    	
    }
    
}

