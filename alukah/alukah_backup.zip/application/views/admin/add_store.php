
<div class="block">
    <h3 class="block-title">اضافة الى المتجر</h3>
    <div class="with-padding">
        <form enctype="multipart/form-data" action="<?=$_SERVER['REQUEST_URI']?>" method="post" id="addstore">
        <fieldset class="fieldset fields-list">

            <legend class="legend">معلومات المنتج</legend>

            <!-- Standard line -->
            <div class="field-block button-height">

                <label for="input-1" class="label">اسم الكتاب</label>
                <input type="text" name="book_name" id="input-1" value="" class="input validate[required]">
                <small class="input-info"></small>


                <label for="input-1" class="label">تاريخ النشر</label>
                <input type="text" name="publish_date" style="direction:ltr" class="input validate[required,custom[date]]" value="<?=date("Y-m-d")?>">
                <small class="input-info"></small>


                <label for="input-1" class="label">صورة الكتاب</label>
                <input type="file" class="file" name="book_image">
                <small class="input-info"></small>
            </div>

            <!-- Carved line -->
            <div class="field-drop button-height black-inputs">
                <label for="input-2" class="label">ارفاق ملف <img src="img/fineFiles/32/pdf.png"> </label>
                <input type="file" class="file" name="book_extra">
            </div>


            <div class="field-block button-height">
                <label for="input-1" class="label">سعر الكتاب</label>
                <span class="number input">
                    <button type="button" class="button number-down">-</button>
                    <input type="text" value="0.99" name="book_price" size="4" class="input-unstyled" data-number-options='{"min":0.99,"max":30,"increment":0.5,"shiftIncrement":5,"precision":0.25}'>
                    <button type="button" class="button number-up">+</button>
                </span>
                <small class="input-info"></small>


                <label for="input-1" class="label">سياسة النشر</label>
                <select name="book_type" class="select check-list">
                    <option value="1">مجاني</option>
                    <option value="2">مدفوع</option>
                </select>
                <small class="input-info"></small>

                <label for="input-1" class="label">تحديد اتجاه الصفحات</label>
                <select name="book_dir" class="select check-list validate[required]" multiple>
                    <option value="1">من اليسار الى اليمين</option>
                    <option value="2">من اليمين الى اليسار</option>
                </select>
                <small class="input-info"></small>


                <label for="input-1" class="label">العنوان التقني للكتاب</label>
                 <span class="input">
                    <input type="text" name="store_id" id="pseudo-input-4" class="input-unstyled validate[required]" value="">
                    <span class="info-spot">
                        <span class="icon-info-round"></span>
                        <span class="info-bubble">
                            مثال :com.alukah_paid.itunes
                        </span>
                    </span>
                </span>
                <small class="input-info"></small>

                <button class="button glossy mid-margin-right" type="submit">
                    <span class="button-icon"><span class="icon-tick"></span></span>
                    اضافة
                </button>
            </div>
        </fieldset>
     </form>

    </div>
</div>

<script>
    $(document).ready(function() {
        //$("#addstore").validationEngine();
        $('.datepicker').glDatePicker({  selectableYears: [2013, 2014], monthNames: null , zIndex: 100 });

        <?php
            if(!empty($message) && $ok){
                echo "notify('$message', 'تنبيه', {
                            icon: 'img/demo/icon.png',
                            showCloseOnHover: false,
                            hPos: 'right',
                            groupSimilar: false
                        });";
            }
        ?>

    });

</script>