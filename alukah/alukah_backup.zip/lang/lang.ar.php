<?php

    $SiteLang = array(
                        ## HOME PAGE
                        'BTN_HOME' => 'ÇáÑÆíÓíÉ',
                        'BTN_LOGIN' => 'ÏÎæá',
                        'BTN_SIGNUP' => 'ÊÓÌíá',
                        'BTN_LOGOUT' => 'ÎÑæÌ',
                        'BTN_CP' => 'áæÍÉ ÇáÊÍßã',
                        'BTN_LANG' => 'English',
                        'BTN_MY_LANG' => 'en',
                        'LABEL_CAT' => 'ÇáÃÞÓÇã',
                        
                        ## LOGIN PAGE                        
                        'LABEL_LOGIN' => 'ÏÎæá',
                        'LABEL_FIELD_LOGIN' => 'ÈÑíÏß (Úáì Çäå ÇÓã ÇáÍÓÇÈ)',
                        'LABEL_FIELD_PASS' => 'ßáãÉ ÇáÓÑ',
                        'BTN_ENTER' => 'ÇÐåÈ',
                        'ALT_ENTER' => 'íÚãá',
                        'BTN_CHANGE' => 'ÊÚÏíá',
                        'LABEL_WELCOME' => 'ÃåáÇ ',
                        
                        ## LOGIN PROCCESS                        
                        'LOGIN_MSG_CHECK' => 'íÑÌì ÇáÊÍÞÞ ãä ÇáÍÞæá',
                        'LOGIN_MSG_NOT_FOUND' => 'ÚÐÑÇ , ÇáÍÓÇÈ ÇáãØáæÈ ÛíÑ ãæÌæÏ Ýí ÞÇÚÏÉ ÇáÈíÇäÇÊ',
                        'LOGIN_MSG_NOT_ACTIVE' => 'ÚÐÑÇ , ÍÓÇÈß áã íÊã ÊÝÚíáå ÈÚÏ',
                        'LOGIN_MSG_WRONG_PASS' => 'ÚÐÑÇ , áÞÏ ÇÏÎáÊ ßáãÉ ãÑæÑ ÎÇØÆÉ',
                        'LOGIN_MSG_SUCCESS' => 'Êã ÇáÏÎæá ÈÇáäÌÇÍ',
                        'MSG_AUTO_REDI' => 'ÇáÂä ÓæÝ íÊã ÊÍæíáß Çáì ÇáÑÆíÓíÉ',
                        
                        ## Department Page
                        'APPROVAL_MSG' => '<h2>ÈÚÖ ÇáãÚáæãÇÊ:</h2><p><small><strong>ãáÇÍÙÉ: </strong>íãßäß Çä ÊÔÇåÏ ÇáÃÞÓÇã ÈÍÓÈ ÍÇáÉ ÇáãæÇÝÞÉ , íãßäß ÅÎÊíÇÑ ÇáãæÇÝÞÉ ÇáãÈÏÆíÉ Çæ ÇáãæÇÝÞÉ ÇáäåÇÆíÉ</small></p>',
                        'APPROVAL_BTN1' => 'ÇáãæÇÝÞÉ ÇáãÈÏÆíÉ',
                        'APPROVAL_BTN2' => 'ÇáãæÇÝÞÉ ÇáäåÇÆíÉ',
                        
                        ## SIGNUP PAGE                        
                        'SIGNUP_LABEL_TITLE' => 'ÇáÊÓÌíá',
                        'SIGNUP_LABEL_ALT' => 'Åäå ãÌÇäí æíãßä áÃí ÔÎÕ ÇáÅäÖãÇã ÅáíäÇ',
                        'SIGNUP_LABEL_NAME' => 'ÇáÅÓã ÇáßÇãá',
                        'SIGNUP_LABEL_NAT' => 'ÇáÌäÓíÉ',
                        'SIGNUP_LABEL_EMAIL' => 'ÈÑíÏß ÇáÅáßÊÑæäí',
                        'SIGNUP_LABEL_PASS' => 'ßáãÉ ÇáÓÑ',
                        'SIGNUP_LABEL_TYPE' => 'äæÚ ÇáÍÓÇÈ',
                        'SIGNUP_LABEL_GENDER' => 'ÇäÇ',
                        'SIGNUP_LABEL_BRITHDAY' => 'íæã ÇáãíáÇÏ',                        
                        'SIGNUP_PASS_WEAK' => 'ÖÚíÝ',
                        'SIGNUP_PASS_MEDIUM' => 'ãÊæÓØ',
                        'SIGNUP_PASS_STRONG' => 'Þæí',
                        
                        'SIGNUP_TYPE_0' => 'ÅÎÊÑ ÇáäæÚ',
                        'SIGNUP_TYPE_1' => 'ÚÖæ',
                        'SIGNUP_TYPE_2' => 'ÔÑßÉ',
                        'SIGNUP_TYPE_3' => 'ãÔÑÝ',
                        'SIGNUP_TYPE_4' => 'ÅÏÇÑí',
                        
                        'SIGNUP_SEX_1' => 'ÅÎÊÑ ÇáÌäÓ',
                        'SIGNUP_SEX_2' => 'ÃäËì',
                        'SIGNUP_SEX_3' => 'ÐßÑ',
                        
                        'SIGNUP_MONTH' => 'ÇáÔåÑ',
                        'SIGNUP_DAY' => 'Çáíæã',
                        'SIGNUP_YEAR' => 'ÇáÓäÉ',
                        
                        ## SIGNUP PROCCESS 
                        'SIGNUP_MSG_FIELDS' => 'ÌãíÚ ÇáÍÞæá ãØáæÈÉ',
                        'SIGNUP_MSG_INVALID' => 'áÞÏ ÞãÊ ÈÅÏÎÇá ÚäæÇä ÈÑíÏ ÛíÑ ÕÇáÍ',
                        'SIGNUP_MSG_SEX' => 'íÌÈ ÅÎÊíÇÑ ÇáÌäÓ ãä ÇáÞÇÆãÉ',
                        'SIGNUP_MSG_TYPE' => 'íÌÈ ÅÎÊíÇÑ äæÚ ÇáÍÓÇÈ ãä ÇáÞÇÆãÉ',
                        'SIGNUP_MSG_NAT' => 'ÚÐÑÇ , æáßä ÞãÊ ÈßÊÇÈÉ Çæ ÇÎÊíÇÑ ÌäÓíÉ ÛíÑ ÕÍíÍÉ',
                        'SIGNUP_MSG_BRITHDAY' => 'íÌÈ ãáÃ ÍÞæá íæã ãíáÇÏß ãä ÇáÞÇÆãÉ',
                        'SIGNUP_MSG_PROV' => 'áã ÊÞã ÈÅÏÎÇá ÈÑíÏ ÇáßÊÑæäí ÕÇáÍ',
                        'SIGNUP_MSG_EXISTS' => 'ÇáÈÑíÏ ÇáÐí ÃÏÎáÊå ãæÌæÏ ãÓÈÞÇ áÍÓÇÈ ÂÎÑ Ýí ÞÇÚÏÉ ÇáÈíÇäÇÊ',
                        
                        ## USERCP
                        'USERCP_LABEL_CHPRO' => 'ÊÛííÑ ÇáãáÝ ÇáÔÎÕí',
                        'USERCP_LABEL_CHPASS' => 'ÊÛííÑ ßáãÉ ÇáÓÑ',
                        'USERCP_LABEL_CHPIC' => 'ÊÛííÑ ÇáÕæÑÉ ÇáÔÎÕíÉ',                        
                        
                        'USERCP_LABEL_ADD' => 'ÅÖÇÝÉ ÑÇÈØ',
                        'USERCP_DESC_ADD' => 'íãßäß ÅÖÇÝÉ ÑÇÈØ ãÈÇÔÑÉ ãÚ ÇáÊÍßã ÇáßÇãá Èå , æÇÎÊíÇÑ ÇáÞÓã ÇáãÍÏÏ ÇáÐí ÓíÞÏã Öãäå',
                        'USERCP_LABEL_LIST' => 'ÞÇÆãÉ ÇáÑæÇÈØ',
                        'USERCP_DESC_LIST' => 'ÇáÂä ÈÈÓÇØÉ ¡ íãßäß Çä ÊÑì ßá ÇáÑæÇÈØ ÇáÊí ÃÏÎáÊåÇ Ýí æÞÊ ÓÇÈÞ Ýí ÍÓÇÈß Ýí ãæÞÚäÇ æÊÚÏíáåÇ Ãæ ÍÐÝåÇ',
                        'USERCP_LABEL_PROFILE' => 'ÊÛííÑ ÇáãáÝ ÇáÔÎÕí',
                        'USERCP_DESC_PROFILE' => 'ÊÝÇÚá ãÚäÇ ¡ íãßäß ÇáÂä ÊÛííÑ ÇáãÚáæãÇÊ ÇáÎÇÕÉ Èß æÕæÑÉ ÔÎÕíÉ Ãæ ßáãÉ ÇáãÑæÑ ááÍÓÇÈ',
                        
                        ## USERCP::Add link page
                        'ADDLINK_LABEL_HEADER' => 'ÅÖÇÝÉ ÑÇÈØ',
                        'ADDLINK_LABEL_URL' => 'ÇáÑÇÈØ',
                        'ADDLINK_LABEL_TITLE' => 'ÇáÚäæÇä',
                        'ADDLINK_LABEL_THUMBNAIL' => 'ÇáÕæÑÉ',
                        'ADDLINK_LABEL_DESCRIPTION' => 'ÇáÊÝÇÕíá',
                        'ADDLINK_LABEL_MEMBER' => 'ÅÓã ÇáÍÓÇÈ',
                        'ADDLINK_LABEL_DEPT' => 'Ýí ÇáÞÓã',

                        ##USERCP::addlink PROCCESS                        
                        'ADDLINK_MSG_REQ' => 'ÌãíÚ ÇáÍÞæá ãØáæÈÉ',
                        'ADDLINK_MSG_DEPT' => 'íÌÈ Úáíß ÅÎÊíÇÑ ÇáÞÓã',
                        'ADDLINK_MSG_EXISTS' => 'ÇáÈÑíÏ ÇáÅáßÊÑæäí ÇáãÏÎá ãæÌæÏ ÈÇáÝÚá ÓÇÈÞÇ',
                        'ADDLINK_MSG_SUB' => 'ÇáÑÇÈØ ÇáãÑÓá ÞÏ Êã ÅÏÎÇáå ÈäÌÇÍ',
                        'ADDLINK_MSG_AUTO' => 'ÇáÂä ÓæÝ íÊã ÊÍæíáß Çáì áæÍÉ ÇáÊÍßã',
                        
                        ##USERCP::profile PAGE
                        'PROFILE_LABEL_TITLE' => 'ãÚáæãÇÊ ÃÓÇÓíÉ',
                        'PROFILE_LABEL_NAME' => 'ÅÓãß',
                        'PROFILE_LABEL_EMAIL' => 'ÈÑíÏ ÇáÅáßÊÑæäí',
                        'PROFILE_LABEL_NAT' => 'ÇáÌäÓíÉ',
                        'PROFILE_LABEL_TYPE' => 'äæÚ ÇáÍÓÇÈ',
                        'PROFILE_LABEL_GENDER' => 'ÃäÇ',
                        'PROFILE_LABEL_BIR' => 'ÚíÏ ãíáÇÏß',
                        
                        ## USERCP::profile PROCCESS
                        'PROFILE_MSG_REQ' => 'ÌãíÚ ÇáÍÞæá ãØáæÈÉ',
                        'PROFILE_MSG_BIR' => 'íÌÈ Úáíß ÅÎÊíÇÑ ÚíÏ ãíáÇÏß ãä ÇáÞÇÆãÉ',
                        'PROFILE_MSG_NAT' => 'ÚÐÑÇ , áßäß ÍÇæáÊ ÊÍÏíÏ ÌäÓíÉ ÛíÑ ÕÇáÍÉ',
                        'PROFILE_MSG_TYP' => 'íÌÈ Úáíß ÅÎÊíÇÑ äæÚ ÇáÍÓÇÈ',
                        'PROFILE_MSG_UPD' => 'áÞÏ Êã ÊÚÏíá ãáÝß ÇáÔÎÕí ÈäÌÇÍ',
                        
                     );

?>
