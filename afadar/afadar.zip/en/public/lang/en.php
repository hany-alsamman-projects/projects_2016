<?php

$lang = array('error_pass'    => 'You entred wrong password !', //login
              'no_data'       => 'Sorry nothing found in database !', //login
			  'login_start'   => 'Welcome', //login
			  'log_out'       => 'Tace Care !', //logout
			  'error_send'    => 'There has been a mail error sending to', //error send mail
			  'error_access'  => 'Dont have access for this section, your account under some restriction!',
			  ''			 
			 );

?>