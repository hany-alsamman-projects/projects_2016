<?php

/*
Write below the email address where you wish
to receive the email notifications.
This is required.
*/
$mailTo = "info@afadar-jewelry.com";


/*
If you want you can register your own reCAPTCHA
Public Key and Private Key. To do so, visit reCAPTCHA.net and follow
the onscreen instructions to get your Public and Private Key.
Once Done you can paste them here overwriting the existing ones below.
*/
$publickey = "6Lfs-sUSAAAAAJ2SbFuIMWC3ilimixBt3Q9D5VHt";
$privatekey = "6Lfs-sUSAAAAAM4bUHOxDIYiZvMsd6cHFOqpbGts";


/*
You can disable reCAPTCHA on your form by simply setting the below value to false.
i.e. $reCAPTCHA = false;
By setting the below value to false reCAPTCHA will not be visible in your form.
*/
$reCAPTCHA = false;

/*
If you want to disable the Uploads feature, just set the below value to false.
i.e. $uploadify = false;
*/
$uploadify = true;


/*
If you want to disable the GeoLocation and Google Map features, just set the below value to false.
i.e. $location = false;
*/
$location = true;

/*
If you want to disable the Social Share feature, just set the below value to false.
i.e. $addthis = false;
*/
$addthis = false;
?>