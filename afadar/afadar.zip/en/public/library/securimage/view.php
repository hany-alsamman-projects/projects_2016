<?php

include 'securimage.php';

$img = new securimage();

$img->show();

?>
