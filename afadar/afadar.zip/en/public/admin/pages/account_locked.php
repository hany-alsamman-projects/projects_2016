<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
<title><? print SITE_NAME ?> - <? print $lang['login'] ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256" />
<meta http-equiv="Content-Language" content="ar-sy" />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>

<body style="margin:0; padding:0" onload="window.status='<? print SITE_NAME ?>';return true;">

<table width="100%" height="100%">
		<tr>
			<td width="50%" align="center" height="100%">
            your account has been locked
			</td>
		</tr>
</table>

</body>
</html>