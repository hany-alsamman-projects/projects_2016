      <div id="sub_root">
        <div id="content">
          <div id="b_bg" style="height:480px;">
            <div id="amc_bg" >
                  
                  <?php
				  
				  if($_GET['id'] == 3){
				  	include ('./templates/contactus.php');
					  
				  }
                  
				  if($_GET['id'] == 2){
				  	include ('./templates/aboutus.php');
					  
				  }
				  
				  ?> 
            </div>
          </div>
        </div>
        </div>