      <div id="intro">
        
        <div id="photos_board">                     
              
            <div style="width: 800px;">
                                                   
              <div id='prodcut_fram' class="floatLeft round-corners shadowbox">
                    <div class="prodcutsub round-corners">      
                        <img src="../upload/device_in.jpg" />                     
                    </div>
                    <div class="prodcuttitle"><b>Plasmalipo</b></div>
              </div>
                    
            </div>
        
        </div>            

      </div>