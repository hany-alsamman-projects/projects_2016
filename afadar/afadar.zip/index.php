<?php

header('Location: en/'); 

?>