(function($) {
    "use strict";
    var htmlTag = $('html'),
        device  = false,
        deviceAndroid = false,
        videoBg = false,
        deviceMobile = false,
        notAnimated = false,
        clickActions = Modernizr.touch ? 'touchstart' : 'click';

    if(htmlTag.hasClass('tablet') || htmlTag.hasClass('mobile')){
        device = true;
    }
    if(htmlTag.hasClass('android')){
        deviceAndroid = true;
    }
    if(htmlTag.hasClass('mobile')){
        deviceMobile = true;
    }
    if(htmlTag.find('#wrapper').is('.has-video-background')){
        videoBg = true;
    }
    if(!Modernizr.cssanimations && !Modernizr.csstransitions){
        notAnimated = true;
    }

    var selectors = {
        bigText : '.b-slider-descr:visible > p > span',
        fancyTitle: '.m-fancy-animate .e-large-title',
        switcherSelector: '.b-view-list',
        dropDownTrigger: '.e-dropdown-trigger',
        overlayClass: '.b-loader-overlay',
        portfolioBlock: '.b-portfolio',
        testimonialsBlock: '#testimonialsBlock'
    }
    /* Responsive image init */

    $('.slides-container img').breakpoint();

    /*End responsive image init*/

    /* Query loader init */

    if (device) {
        window.addEventListener("DOMContentLoaded", function () {
            $("body").queryLoader2({
                showbar: "on",
                barColor: "inherit",
                backgroundColor: "#fff",
                percentage: true,
                barHeight: 4,
                completeAnimation: "fade",
                minimumTime: 100,
                onLoadComplete: function(){
                    mainSliderFunctionality();
                    $(selectors.overlayClass).delay(200).animate({'opacity': 0}, function(){
                        $(this).hide().remove();
                    });
                    $('.b-slider-descr:visible > p > span').bigText({
                        limitingDimension: 'width',
                        fontSizeFactor: 1.1
                    });
                }
            });
        });
    } else {
        $("body").queryLoader2({
            showbar: "on",
            barColor: "inherit",
            backgroundColor: "transparent",
            percentage: true,
            barHeight: 4,
            deepSearch: true,
            completeAnimation: "grow",
            minimumTime: 500,
            onLoadComplete: function(){
                mainSliderFunctionality();
                $(selectors.bigText).bigText({
                    limitingDimension: 'width',
                    fontSizeFactor: 1.1
                });
                $(selectors.overlayClass).delay(200).animate({'opacity': 0}, function(){
                    $(this).hide().remove();
                });
            }
        });
    }

    /* End Query loader init */

    /* Background video */

    var wordCarouselInit = function(){
        var container = $('.b-in-main-slider .slides-container'),
            wrapper = $('.b-fullscreen-video'),
            wHeight = $(window).height();

        wrapper.height(wHeight);

        if(!container.size()) return false;
        container.owlCarousel({
            slideSpeed : 300,
            mouseDrag: false,
            navigation : true,
            pagination: false,
            autoPlay: 6000,
            addClassActive: true,
            transitionStyle : "fade",
            paginationSpeed: 1000,
            scrollPerPage: true,
            dragBeforeAnimFinish: false,
            singleItem: true
        });
        $(window).on('resize orientationchange', function(){
            wrapper.height($(window).height());
            setTimeout(function(){
                container.find('.b-slider-descr:visible > p > span').bigText({
                    limitingDimension: 'width',
                    fontSizeFactor: 1.1
                });
            }, 200);
        });
    }();
    /* Background video */

    /* Main slider */
    var mainSliderFunctionality = function(){
        var api;
        api =  jQuery('.fullwidthabnner').revolution(
            {
                delay:9000,
                startheight: 650,
                startwidth:960,

                hideThumbs:10,

                thumbWidth:100,							// Thumb With and Height and Amount (only if navigation Tyope set to thumb !)
                thumbHeight:50,
                thumbAmount:2,

                navigationType:"both",					//bullet, thumb, none, both		(No Thumbs In FullWidth Version !)
                navigationArrows:"verticalcentered",		//nexttobullets, verticalcentered, none
                navigationStyle:"round",				//round,square,navbar

                touchenabled:"on",						// Enable Swipe Function : on/off
                onHoverStop:"off",						// Stop Banner Timet at Hover on Slide on/off

                navOffsetHorizontal:0,
                navOffsetVertical:20,

                stopAtSlide:-1,
                stopAfterLoops:-1,

                shadow:1,								//0 = no Shadow, 1,2,3 = 3 Different Art of Shadows  (No Shadow in Fullwidth Version !)
                fullWidth:"on"							// Turns On or Off the Fullwidth Image Centering in FullWidth Modus
            });

    };

    /* End main slider */

    /* Nav menu functionality */

    var navMenu = function(){
        var menuTrigger = $('.e-menu-trigger'),
            menuWrapper = menuTrigger.closest('.b-main-menu-wrapper'),
            menuContainer = menuWrapper.find('.b-main-menu-inner');

        var activeToggler = function(trigger){
            var trigger = trigger || menuTrigger.filter('.m-active');
            trigger.toggleClass('m-active').closest('.b-main-menu-wrapper').toggleClass('m-active').find('.b-main-menu-inner').toggleClass('m-active');

        };
        menuTrigger.on(clickActions, function(e){
            activeToggler($(this));
            e.preventDefault();
        });

        //Close menu when click on outside
        $(document).on('click touchend', function(e){
            if(menuWrapper.hasClass('m-active')){
                if( !$('body').find(e.target).closest('.main-menu').size() && !$('body').find(e.target).hasClass('e-menu-trigger'))
                    activeToggler();
            }
        });
    }();

    var navMenuScroll = function(){
        var menuContainer = $('.menu-items');
        return menuContainer.on('click tap touchend','a[href*=#]:not([href=#])', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
                if (target.length) {

                    $('html,body').animate({
                        scrollTop: target.children(':first:not(script)').offset().top
                    }, 1000);
                }
            }
        });
    }();
    /* End nav menu functionality */

    var countedNumbers = function(wrapper){
        var container = wrapper || $('.b-counters-block'),
            counterItems = container.find('.e-counter-item');

        if (container.hasClass('m-done') || !counterItems.size()){
            return false;
        }
        counterItems.each(function(){
            var $self = $(this),
                countedNumber = parseInt($self.data('count-number'));

            if(countedNumber){
                $self.animateNumber({
                    number: countedNumber,
                    easing: 'easeInQuad'
                }, 2500);
            }
        });
    };

    /* Inview functionality */
    if(!device){
        $('.b-counters-block').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
            if(isInView && visiblePartY == 'both' || isInView && visiblePartY == 'top'){
                countedNumbers();
                $(this).addClass('m-done fade-in-animate');
            }
            if(typeof visiblePartY === 'undefined' && $(window).scrollTop() < $(this).offset().top){
                $(this).removeClass('fade-in-animate m-done');
            }
        });

        $('.b-about-company .b-content').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
            if(isInView && visiblePartY == 'both' || isInView && visiblePartY == 'top'){
                $(this).addClass('fadeInUp-animate');
            }
            if(typeof visiblePartY === 'undefined' && $(window).scrollTop() < $(this).offset().top){
                $(this).removeClass('fadeInUp-animate');
            }
        });

        $('.b-about-company h1').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
            if(isInView && visiblePartY == 'both'){
                $(this).addClass('fadeInUp-animate');
            }
            if(isInView && visiblePartY == 'top'){
                $(this).addClass('fadeInUp-animate')
            }
            if(typeof visiblePartY === 'undefined' && $(window).scrollTop() < $(this).offset().top){
                $(this).removeClass('fadeInUp-animate');
            }
        });

        //Quote block
        if(!videoBg){
            $('.b-quote-wrapp').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
                var $self = $(this);
                if(isInView){
                    $self.addClass('background-animate');
                }else{
                    $self.removeClass('background-animate');
                }
            });
        }
        var animationProgress = function(time){
            var animationTime = time || 3000,
                step = animationTime/100,
                progressCounter = 0,
                progressBlock =  $('.m-fancy-animate > .b-animation-progress');

            progressBlock.width(0);

            var progressStep = setInterval(function(){
                if(progressCounter < animationTime ){
                    progressCounter += step;
                    progressBlock.width((progressCounter/animationTime)*100+'%');
                }else{
                    clearInterval(progressStep);
                    return false;
                }
            }, step);

        };
        $(selectors.fancyTitle).on('inview', function(event, isInView, visiblePartX, visiblePartY) {
            var mainContainer = $(this).closest('.m-fancy-animate'),
                animateTitle = mainContainer.find('.e-large-title'),
                totalTime = 4500,
                k = notAnimated ? 3 : 1,
                progressBlock = $('<div />', {'class': 'b-animation-progress'});
            if(isInView && visiblePartY == 'top' || isInView && visiblePartY == 'both'){

                if(!mainContainer.hasClass('scroll-done')){

                    if(!mainContainer.find('.b-animation-progress').size()){
                        mainContainer.append(progressBlock);
                    }
                    animationProgress(totalTime);
                    $('html, body').animate({
                        scrollTop: mainContainer.find('.row').first().offset().top
                    }, 500, function(){

                        mainContainer.addClass('scroll-done');
                        mainContainer.find('.m-first-state').addClass('fade-in-out-animate');
                        setTimeout(function(){
                            mainContainer.find('.m-first-state').addClass('m-fade-in');
                            animateTitle.addClass('m-first-step');
                        }, 3500/k);

                        setTimeout(function(){
                            mainContainer.find('.m-first-state').removeClass('m-first-state');
                            animateTitle.addClass('m-second-step');
                        }, 5500/k);

                        setTimeout(function(){
                            mainContainer.addClass('m-done-action')
                        }, totalTime/k);
                        return false;
                    });
                }
            }

        });
    }
    /* End inview functionality */

    /* Dropdown functionality */


    function removeActive(dropdown){
        var activeDropdown = dropdown || $('body').find('.b-dropdown').filter('.m-active'),
            trigger = $('body').find('a').filter('[href*="'+activeDropdown.prop('id')+'"]');

        if(!activeDropdown.size()) return false;
        setTimeout(function(){
            $('body').find('.b-dropdown').removeClass('m-animated');
            activeDropdown.removeAttr('style');
        }, 1000);

        if(trigger.size()){
            trigger.each(function(){
                $(this).removeClass('m-active m-animated');
            });
        }
        skillsInit(activeDropdown, 'clear');
        activeDropdown.find('.b-side-content').animate({'scrollTop':'0'}, 500);
        if(notAnimated){
            activeDropdown.slideUp().removeClass('m-active');
        }else{
            activeDropdown.removeClass('m-active');
        }
    }
    //close on press esc
    $(document).on('keyup', function(e){
        var key = e.keyCode;
        if(key == 27){
            removeActive();
        }
    });

    $('.b-dropdown-items a, .e-dropdown-lnk, .b-overlay-descr a').on('click tap', function(e){
        var $self = $(this),
            dropDownContainerClass = '.b-dropdown',
            elemDD= $('body').find($self.attr('href'));
        e.preventDefault();
        if(!elemDD.size() || $('body').find(dropDownContainerClass).is('.m-animated')){
            return false;
        }

        if(!elemDD.hasClass('m-active')){
            if($('body').find(dropDownContainerClass).is('.m-active')){
                //Open if another dropdown active
                removeActive();
                if(notAnimated){
                    elemDD.slideDown(function(){
                        if(elemDD.find('.b-map-wrapper').size()){
                            mapInit();
                        }
                    }).addClass('m-animated');
                }else{
                    elemDD.css('display', 'block').addClass('m-animated');
                    if(elemDD.find('.b-map-wrapper').size()){
                        mapInit();
                    }
                }

                setTimeout(function(){
                    elemDD.addClass('m-active');
                }, 500);
            }else{
                //if first opening
                if(notAnimated){
                    elemDD.addClass('m-animated').slideDown(function(){
                        elemDD.addClass('m-active');
                        $('body').find(dropDownContainerClass).filter('.m-animated').removeClass('m-animated');
                        if(elemDD.find('.b-map-wrapper').size()){
                            mapInit();
                        }
                    });
                }else{
                    elemDD.css('display', 'block').addClass('m-animated');
                    if(elemDD.find('.b-map-wrapper').size()){
                        mapInit();
                    }
                    setTimeout(function(){
                        elemDD.addClass('m-active');
                    }, 200);
                    setTimeout(function(){
                        $('body').find(dropDownContainerClass).filter('.m-animated').removeClass('m-animated');
                    }, 500);
                }
            }

            skillsInit(elemDD);

            $self.addClass('m-active');
            elemDD[0].addEventListener("touchmove", function(evt){
                evt.stopPropagation();
            }, false);
            elemDD.find('.b-side-content').delay(500).animate({'scrollTop': '200%'}, function(){
                $(this).delay(500).animate({'scrollTop': '0'});
            });
        }else{
            return false;
        }
        return false;
    });

    /* In open dropdown activity */
    function skillsInit(wrapper, action){
        //if(deviceMobile) return false;
        var container = wrapper || $('.b-dropdown.m-active').find('.b-skill-list'),
            skillItems = container.find('.e-skill-spinner');

        if(skillItems.size()){
            if(action == 'clear'){
                if(!device){
                    skillItems.each(function(){
                        $(this).find('.e-skill-progress').width(0);
                    });
                    return false
                }
            }else{
                skillItems.each(function(){
                    var $self = $(this),
                        duraction = 1100,
                        progressLine = $self.find('.e-skill-progress'),
                        persentDisplay = progressLine.find('.e-skill-count'),
                        skillValue = parseInt(progressLine.data('skill-value'));
                    if(device){
                        duraction = 0;
                    }
                    if(skillValue > 100){
                        skillValue = 100;
                    }else if (skillValue < 0){
                        skillValue = 0
                    }
                    progressLine.width(skillValue+'%');
                    persentDisplay.animateNumber({
                        number: skillValue,
                        easing: 'easeInQuad',

                        // optional custom step function
                        // using here to keep '%' sign after number
                        numberStep: function(now, tween) {
                            var floored_number = Math.floor(now),
                                target = $(tween.elem);

                            target.text(floored_number + '%');
                        }
                    }, duraction);
                });
            }
        }
    }

    /* End in open dropdown activity */

    $(selectors.dropDownTrigger).on('click touchstart', function(e){
        removeActive($(this).closest('.b-dropdown'));
        e.preventDefault();
    });

    /* Dropdown functionality */

    /* End mobile main menu functionality */

    /* Contact Us */
    $('#requestForm').submit(function() {
        var form = $(this),
            requaredFields = form.find('.e-required-field'),
            isError = false;

        form.find('.b-error-msg, .b-success-msg').remove();

        requaredFields.each(function() {
            var field = $(this);
            field.removeClass('m-not-valid');
            if($.trim(field.val()) === '') {
                field.addClass('m-not-valid').siblings('label').append('<span class="b-error-msg">This is a required field.</span>');
                isError = true;
            } else if(field.hasClass('e-email-field')) {
                var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                if(!emailReg.test($.trim($(this).val()))) {
                    field.addClass('m-not-valid').siblings('label').append('<span class="b-error-msg">You entered an invalid Email.</span>');
                    isError = true;
                }
            }
        });
        if(!isError) {
            var formData = $(this).serialize();
            $.post('contacts.html', formData, function(data) {
                requaredFields.val('');
                form.find('.row').last().append('<div class="b-success-msg">Thank you! We will contact you shortly.</div>');
            }).fail(function() {
                form.find('.row').last().append('<div class="b-error-msg">Error occurred. Please try again later.</div>');
            });
        }
        return false;
    });
    /* End Contact Us */

    /* Brands carousel init */

    var brandsFunctionality = function(){
        var brandCarouselContainer = $('#brandsCarousel'),
            brandCarouselData = '';
        if (!brandCarouselContainer.size()) return false;
        $('#brandsBlock').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
            var $self = $(this);
            if(isInView && visiblePartY == 'both'){
                brandCarouselData.play();
            }else if(typeof visiblePartY === 'undefined' && $(window).scrollTop() < $(this).offset().top){
                brandCarouselData.stop();
            }
        });
        brandCarouselContainer.owlCarousel({
            navigation : false,
            pagination: false,
            autoPlay: 5000,
            itemsDesktop : [1280,4]
        });

        brandCarouselData = brandCarouselContainer.data('owlCarousel');
        brandCarouselData.stop();
    }();

    /* End brands carousel init */
    /* Twitter init */

    var twitterFeedInit = function(){
        var container = $('#twitterCarousel'),
            time = 15,
            carouselData,
            $progressBar,
            $bar,
            $elem,
            isPause,
            tick,
            percentTime;

        if(!container.size()) return false;


        container.tweet({
            modpath: "twitter/",
            join_text: "auto",
            count: 4,
            avatar_size: 0,
            template: "{text}{time}",
            username: "envato"
        });

        if(container.find('.tweet_list').size()){
            container.find('.tweet_list').owlCarousel({
                slideSpeed : 200,
                mouseDrag: true,
                navigation : false,
                pagination: true,
                autoPlay: false,
                transitionStyle : "fade",
                paginationSpeed: 500,
                scrollPerPage: true,
                dragBeforeAnimFinish: true,
                itemsScaleUp: true,
                singleItem: true,
                afterInit : progressBar,
                afterMove : moved,
                startDragging : pauseOnDragging
            });
        }else{
            return false;
        }


        //Init progressBar
        function progressBar(elem){
            $elem = elem;
            //build progress bar elements
            buildProgressBar();
            //start counting
            start();
        }

        //create div.progressBar
        function buildProgressBar(){
            $progressBar = $("<div>",{
                class:"progressBar"
            });
            $bar = $("<div>",{
                class:"bar"
            });
            $progressBar.append($bar).prependTo($elem);
        }

        function start() {
            //reset timer
            percentTime = 0;
            isPause = false;
            //run interval every 0.01 second
            tick = setInterval(interval, 10);
        }

        function interval() {
            if(isPause === false){
                percentTime += 1 / time;
                $elem.find('.bar').css({
                    width: percentTime+"%"
                });
                //if percentTime is equal or greater than 100
                if(percentTime >= 100){
                    //slide to next item
                    $elem.trigger('owl.next')
                }
            }
        }

        //pause while dragging
        function pauseOnDragging(){
            isPause = true;
        }

        //moved callback
        function moved(){
            //clear interval
            clearTimeout(tick);
            //start again
            start();
        }
        $('#twitterBlock').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
            var $self = $(this);
            if(isInView){
                if(!videoBg){
                    $self.find('.b-background-overlay').addClass('scaleAbsoluteBlock-animate');
                }
                carouselData.play();
                isPause = false;
            }else if(typeof visiblePartY === 'undefined'){
                if(!videoBg){
                    $self.find('.b-background-overlay').removeClass('scaleAbsoluteBlock-animate');
                }
                carouselData.stop();
                isPause = true;
            }
        });

        carouselData = container.find('.tweet_list').data('owlCarousel');
        if(!carouselData) return false;
        carouselData.stop();
        isPause = true;

    }();
    /* End twitter init */

    /* Testimonials carousel */
    var testimonialsFunctionality = function(){
        var container = $('#testimonialsCarousel'),
            testimonialBlock = $(selectors.testimonialsBlock),
            time = 7,
            carouselData,
            $progressBar,
            $bar,
            $elem,
            isPause,
            tick,
            percentTime;

            if(!container.size()) return false;

        container.owlCarousel({
            slideSpeed : 200,
            mouseDrag: false,
            navigation : false,
            pagination: true,
            autoPlay: false,
            transitionStyle : "fade",
            paginationSpeed: 500,
            scrollPerPage: true,
            dragBeforeAnimFinish: true,
            itemsScaleUp: true,
            singleItem: true,
            afterInit : progressBar,
            afterMove : moved,
            startDragging : pauseOnDragging
        });        container.owlCarousel({
            slideSpeed : 200,
            mouseDrag: false,
            navigation : false,
            pagination: true,
            autoPlay: false,
            transitionStyle : "fade",
            paginationSpeed: 500,
            scrollPerPage: true,
            dragBeforeAnimFinish: true,
            itemsScaleUp: true,
            singleItem: true,
            afterInit : progressBar,
            afterMove : moved,
            startDragging : pauseOnDragging
        });

        //Init progressBar
        function progressBar(elem){
            $elem = elem;
            //build progress bar elements
            buildProgressBar();
            //start counting
            start();
        }

        //create div.progressBar
        function buildProgressBar(){
            $progressBar = $("<div>",{
                class:"progressBar"
            });
            $bar = $("<div>",{
                class:"bar"
            });
            $progressBar.append($bar).prependTo($elem);
        }

        function start() {
            //reset timer
            percentTime = 0;
            isPause = false;
            //run interval every 0.01 second
            tick = setInterval(interval, 10);
        }

        function interval() {
            if(isPause === false){
                percentTime += 1 / time;
                $elem.find('.bar').css({
                    width: percentTime+"%"
                });
                //if percentTime is equal or greater than 100
                if(percentTime >= 100){
                    //slide to next item
                    $elem.trigger('owl.next')
                }
            }
        }

        //pause while dragging
        function pauseOnDragging(){
            isPause = true;
        }

        //moved callback
        function moved(){
            //clear interval
            clearTimeout(tick);
            //start again
            start();
        }
        if(!device && !videoBg){
            testimonialBlock.prev().on('inview', function(event, isInView, visiblePartX, visiblePartY){
                if(isInView){
                    testimonialBlock.addClass('m-inprogress');
                }
            });

            testimonialBlock.next().on('inview', function(event, isInView, visiblePartX, visiblePartY){
                if(isInView){
                    testimonialBlock.addClass('m-inprogress');
                }else if(typeof visiblePartY === 'undefined' && $(window).scrollTop() > $(this).offset().top){
                    testimonialBlock.removeClass('m-inprogress');
                }
            });
        }

        testimonialBlock.on('inview', function(event, isInView, visiblePartX, visiblePartY) {
            var $self = $(this);
            if(isInView){
                if(!videoBg){
                    $self.find('.b-background-overlay').addClass('fixed-background-animate');
                }
                carouselData.play();
                isPause = false;
            }else if(typeof visiblePartY === 'undefined'){
                if(!videoBg){
                    $self.find('.b-background-overlay').removeClass('fixed-background-animate');
                }
                carouselData.stop();
                isPause = true;
            }
        });

        carouselData = container.data('owlCarousel');

        carouselData.stop();
        isPause = true;

    }();
    /* End testimonials carousel */

    /* Portfolio functionality */
    var portfolioCarousels = function(){
        var smallCarouselContainer = $('#portfolio-smaller-carousel'),
            normalCarouselContainer = $('#portfolio-normal-carousel'),
            gridContainer = $('#gridView'),
            carouselContainer = $('#carouselView'),
            smallCarouselData,
            normalCarouselData;
        if(!smallCarouselContainer.size() && !normalCarouselContainer.size()) return false;
        var smallCarouselOptions = {
            navigation : false,
            scrollPerPage: true,
            items: 6,
            pagination: false,
            autoPlay: 5000,
            slideSpeed: 800,
            stopOnHover: false,
            itemsDesktop : [1330,5],
            itemsDesktopSmall:	[979,4],
            itemsTablet: [768,3],
            itemsMobile: [479,2]
        };

        var normalCarouselOptions = {
            navigation : false,
            pagination: false,
            items: 5,
            autoPlay: 5000,
            slideSpeed: 1000,
            itemsScaleUp: true,
            stopOnHover: true,
            itemsDesktop : [1330,4],
            itemsDesktopSmall:	[979,3],
            itemsTablet: [768,2]
        };

        smallCarouselContainer.owlCarousel(smallCarouselOptions);

        normalCarouselContainer.owlCarousel(normalCarouselOptions);

        smallCarouselData = smallCarouselContainer.data('owlCarousel');
        normalCarouselData = normalCarouselContainer.data('owlCarousel');

        normalCarouselData.stop();
        smallCarouselData.stop();

        $('.b-portfolio-carousel').on({
            mouseenter: function(){
                smallCarouselContainer.data('owlCarousel').stop();
                normalCarouselContainer.data('owlCarousel').stop();
            },
            mouseleave: function(){
                smallCarouselContainer.data('owlCarousel').play();
                normalCarouselContainer.data('owlCarousel').play();
            }
        });

        $('#portfolioBlock').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
            var $self = $(this);
            if(smallCarouselContainer.data('owlCarousel') && normalCarouselContainer.data('owlCarousel')){
                if(isInView && visiblePartY == 'both'){
                    smallCarouselContainer.data('owlCarousel').play();
                    normalCarouselContainer.data('owlCarousel').play();
                }else if(typeof visiblePartY === 'undefined'){
                    smallCarouselContainer.data('owlCarousel').stop();
                    normalCarouselContainer.data('owlCarousel').stop();
                }
            }
        });
        gridContainer.mixitup({
            targetSelector: '.mix',
            filterSelector: '.filter',
            sortSelector: '.sort',
            buttonEvent: 'click',
            effects: ['scale','fade'],
            listEffects: null,
            easing: 'snap',
            layoutMode: 'grid',
            targetDisplayGrid: 'inline-block',
            targetDisplayList: 'block',
            transitionSpeed: 500,
            showOnLoad: 'all',
            sortOnLoad: false,
            multiFilter: false,
            filterLogic: 'or',
            resizeContainer: true,
            failClass: 'fail',
            perspectiveDistance: '10000',
            perspectiveOrigin: '50% 50%',
            animateGridList: true
        });

        //Switch functionality
        $(selectors.switcherSelector).on('click touchstart', '.e-grid-view', function(e){
            e.preventDefault();
            var scrollTop = $(document).scrollTop();
            $(this).closest('ul').find('a').removeClass('m-active');
            $(this).addClass('m-active').closest('.b-switcher-controls').addClass('m-sort-view');
            smallCarouselContainer.data('owlCarousel').destroy();
            normalCarouselContainer.data('owlCarousel').destroy();



            gridContainer.css('opacity', '0').show();
            carouselContainer.hide();

            normalCarouselContainer.find('> div').addClass('normal-carousel-item').appendTo(gridContainer);
            smallCarouselContainer.find('> div').addClass('small-carousel-item').appendTo(gridContainer);

            gridContainer.mixitup('remix','all');
            gridContainer.mixitup('sort','random');

            gridContainer.css('opacity', '1');

            $(document).scrollTop(scrollTop);

        });
        $(selectors.switcherSelector).on('click touchstart', '.e-carousel-view', function(e){
            e.preventDefault();
            var scrollTop = $(document).scrollTop();
            $(this).closest('ul').find('a').removeClass('m-active');
            $(this).addClass('m-active').closest('.b-switcher-controls').removeClass('m-sort-view');
            gridContainer.hide();
            carouselContainer.css('opacity', '0').show();
            gridContainer.find('> .small-carousel-item').removeClass('small-carousel-item').removeAttr('style').appendTo(smallCarouselContainer);
            gridContainer.find('> .normal-carousel-item').removeClass('normal-carousel-item').removeAttr('style').appendTo(normalCarouselContainer);

            smallCarouselContainer.owlCarousel(smallCarouselOptions);

            normalCarouselContainer.owlCarousel(normalCarouselOptions);

            carouselContainer.css('opacity', '1');

            $(document).scrollTop(scrollTop);
        });
    }();
    /* End portfolio functionality */

    /* Image popup init */
    var LightBoxInit = function(container){
        var container = container || $('.b-overlay-lightbox');

        container.on(clickActions, 'a', function(e){
            var $self = $(this),
                popupType = $self.is('.m-video-popup') ? 'iframe' : 'image';

            container.magnificPopup({
                delegate: $self,
                type: popupType,
                mainClass: 'mfp-zoom-in',
                removalDelay: 500,
                fixedContentPos: true,
                fixedBgPos: true,
                closeOnContentClick: true,
                callbacks: {
                    beforeOpen: function() {
                        // just a hack that adds mfp-anim class to markup
                        this.st.image.markup = this.st.image.markup.replace('mfp-figure', 'mfp-figure mfp-with-anim');
                        this.st.mainClass = 'mfp-zoom-in';
                    }
                },
                image:{
                    cursor: null
                }
            }).magnificPopup('open');
            return false;
        });
        if(device){
            if(!deviceAndroid){
                container.on('tap', 'a', function(e){
                    e.preventDefault();
                    $(this).trigger('click');
                    //return false;
                });
                $('body').on('touchend','.mfp-container', function(){
                    $(this).trigger('click');
                });
            }
        }
    }();
    /* End image popup init */

    if(device){
        $(selectors.portfolioBlock).on('tap', '.mix', function(e){
            var $self = $(this).closest('.owl-item').size() ? $(this).closest('.owl-item') : $(this),
                itemClass = $self.is('.owl-item') ? '.owl-item': '.mix',
                allItems = $self.closest('.b-portfolio').find(itemClass);
            e.stopPropagation();
            e.preventDefault();
            $self.closest('.b-portfolio').find(allItems).removeClass('m-active');
            $self.addClass('m-active');
        });
        $('.b-container').on('tap', function(e){
            $(selectors.portfolioBlock).find('.b-carousel-view:visible .m-active').removeClass('m-active');
            $(selectors.portfolioBlock).find('.b-portfolio-filters:visible .m-active').removeClass('m-active');

        })
    }
	/* Temporary theme switch function */
	
    $('#layoutSwither').on('change', function(){
        var currentColor = ((window.location.pathname.split('/index').join('') !='index.html') && (window.location.pathname.split('/index').join('') !='http://demo.web4pro.net/')) ? window.location.pathname.split('/index').join('') : '.html',
            value = $(this).val();
        currentColor = currentColor.split('/cosmo').join('');
        if(value == 'video' && $(this).not(':selected')){
            window.open ('index-video'+currentColor, '_blank');
        }else{
            window.location = 'index'+currentColor.split('-video').join('');
        }

    });
    if(htmlTag.hasClass('explorer')){
        $('#layoutSwither').on('hover focus active', function(){
            //$(this).closest([class=*'ion-images]').addClass('m-active');
            $(this).closest('.ion-images').addClass('m-active');
            $(this).on('blur', function(){
                $(this).closest('.ion-images').removeClass('m-active');
            })
        });
    }
    
    /* Temporary theme switch function */
})(jQuery);