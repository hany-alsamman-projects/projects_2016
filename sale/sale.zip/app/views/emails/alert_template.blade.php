<tr>
    <td><a href="{{ URL::to('property/'.$task->id) }}">{{ $task->title }}</a></td>
    <td>{{ $task->price }}$</td>
</tr>