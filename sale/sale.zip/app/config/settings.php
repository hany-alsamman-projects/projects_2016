<?php

// {{ Config::get('settings.array.key') }}
// application/config/settings.php

return array(

    'site' => array(
        'charset' => 'utf-8',
        'title' => 'Sale CO :: Driven to excel',
        'metakeys' => 'opened',
        'metadesc' => 'opened',
        'metaauthor' => 'VIP info@vip4it.com'
    ),

    'mailer' => array(
        'charset' => 'utf-8',
        'senderfrom' => 'info@sale-co.com',
        'sendername' => 'Sale CO'
    ),

    'currency_api_key' => '65d27c528af5452d87989f564bbf598c',
    'currency_default' => 'USD'
);
