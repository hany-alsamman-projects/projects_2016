<?php
	
 	//date_default_timezone_set('America/Los_Angeles');
 
	define("PREMIUMPRESS_SYSTEM","RealtorPress");
	define("PREMIUMPRESS_VERSION","6.7");
	define("PREMIUMPRESS_VERSION_DATE","15th Dec, 2011");

	if(defined('TEMPLATEPATH')){ include("PPT/_config.php"); }
 
?>