<?php

class Theme_Design {

/******************************************************************* DEPRECIATED IN 6.3 (SEE PPT/CLASS/CLASS_DESING.PHP) */
function LAY_NAVIGATION(){

	global $PPTDesign;
	
	return $PPTDesign->LAY_NAVIGATION();
}
/*************************************************************************************************/

	function SimilarProperty($num){
	
		global $PPT, $wpdb; $STRING = "";
		
		$pF = $GLOBALS['price']+($GLOBALS['price']/2);
		 
		$posts = query_posts('posts_per_page='.$num.'&meta_key=price&meta_compare=<&meta_value=xXx'.$pF.'xXx&orderby=meta_value_num&cat='.$GLOBALS['singleCategory'][0]->cat_ID); if(count($posts) > 1){
		 
		foreach($posts as $post){ if($post->ID != $GLOBALS['thisID']){ 
					  
			$STRING .= '<li>';
						 
			if(strlen($PPT->Image($post->ID,"url")) > 5){ 
				$STRING .= '<a href="'.get_permalink($post->ID).'" title="'.$post->post_title.'"><img src="'.$PPT->Image($post->ID,"url","&amp;w=80").'" alt="'.$post->post_title.'" width="80" /></a>';
			} 
				$STRING .= '<h2><a href="'.get_permalink($post->ID).'" title="'.$post->post_title.'">'.$post->post_title.'</a></h2><p><b>'.$PPT->Price(get_post_meta($post->ID, "price", true),$GLOBALS['premiumpress']['currency_symbol'],$GLOBALS['premiumpress']['currency_position'],1).'</b></p><p>'.substr($post->post_excerpt,0,170).'..</p>';
				
				
			$STRING .= '</li>';	
			} 
			
			
		
		}
		
		}
		
		wp_reset_query();
		
		return $STRING;
	
	}
 
 		 
 
	
	
 
	
	
	function SINGLE_CUSTOMFIELDS($post,$FieldValues){

	global $wpdb,$PPT;$row=1;

	if($FieldValues ==""){ 
		$FieldValues = get_option("customfielddata");
	}

	if(is_array($FieldValues)){ 

		foreach($FieldValues as $key => $field){

			if(isset($field['show']) && $field['enable'] == 1 ){ 				 
			
			$imgArray = array('jpg','gif','png');

			$value = $PPT->GetListingCustom($post->ID,$field['key'] );
 
			if(is_array($value) || strlen($value) < 1){   }else{			
		
				print "<div class='full clearfix border_t box'><p class='f_half left'><br />"; 
				print "<b>".$field['name']."</b></p><p class='f_half left'><br />";
		
				switch($field['type']){
				 case "textarea": {			
					print "<br />".nl2br(stripslashes($value));
				 } break;
				 case "list": {
					print  $value;
				 } break;
				 default: {
					
					$pos = strpos($value, 'http://'); 					
					if($field['key'] == "skype"){
						print "<a href='skype:".$value."?add'>" .  $value ."</a>";
					}elseif ($pos === false) {
						print  $value;
					}elseif(in_array(substr($value,-3),$imgArray)){
						print "<img src='".strip_tags($value)."' style='max-width:250px;margin-left:20px;'>";
					}else{
						print "<a href='".$value."' target='_blank'";
						if($GLOBALS['premiumpress']['nofollow'] =="yes"){ print 'rel="nofollow"'; }
						print ">" .  $value ."</a>";				
					} 
					
				 }
		
				}
				$row++;
				print "</p></div>";
				
				}

				} 
			}
		}
	
	}	
		
		
		
		 function SINGLE_IMAGEGALLERY($images,$max=100,$de="", $size="400",$ID=""){	
		  
	 
	 global $PPT; $i=0;
	 
	 if($images == ""){ return; } 
	 
	 $images = str_replace($de,"",$images);
	 
	 
		$imgBits = explode("/",get_permalink());	
		$tt = count($imgBits)-2; $it=0;
		
		while($tt > 0){  
			$imagePath .= $imgBits[$it]."/";
			$tt--;$it++;		 
		 }
			 
		 $string = "";
		 $image_array = explode(",",$images); 
	
			foreach($image_array as $image){ if(strlen($image) > 2  ){  if($i < $max){
			 
				switch(substr($image,-3)){ 
					 
							
					case "": {
							
					} break;	
							
					default: {
							$pic1 = $image;
							$class='class="lightbox"';
					}			
						
				}
				
				$string .= '<a class="lightbox" href="'.$PPT->ImageCheck(trim($image),"full").'" rel="group'.$ID.'"><img class="small';
				if($i == 2){ $string .= ' last'; }
				$string .= '" src="'.$PPT->ImageCheck(trim($pic1),"t","&amp;w=".$size).'" style="width:'.$size.'px" alt="img"  /></a>';
				
				$i++;
				
			} }	 }
			
			return $string;
	 
	 }
	 
	 
	 
	 
	 
	 
	function HomeCategories(){
	
		$SHOWCATCOUNT = get_option("display_categories_count");
		 
		$SHOW_SUBCATS = get_option("display_50_subcategories");
	
			if(is_home()){ 
	
				$Maincategories = get_categories('orderby='.get_option("display_homecats_orderby").'&pad_counts=1&use_desc_for_title=1&hide_empty=0&hierarchical=0&child_of=0&exclude='.str_replace("-","",$GLOBALS['premiumpress']['excluded_articles'])); 
					
			}elseif( isset($GLOBALS['premiumpress']['catID']) ){
			
			
				$arg= array();
				$arg['child_of'] = $GLOBALS['premiumpress']['catID'];
				$arg['hide_empty'] = false;
				$arg['pad_counts'] = 1;
				$arg['exclude'] = str_replace("-","",$GLOBALS['premiumpress']['excluded_articles']);
				$Maincategories = get_categories( $arg );
	 
				//$Maincategories = get_categories('orderby='.get_option("display_homecats_orderby").'pad_counts=1&use_desc_for_title=1&hierarchical=0&hide_empty=1&child_of='.$GLOBALS['premiumpress']['catID'].'&exclude='.); 
	  
			} 
	 
	
			if(isset($Maincategories)){
	
			$catlist=""; 
			$Maincatcount = count($Maincategories);	
	 
	
			if($Maincatcount > 0){ $catlist .= '<div class="homeCategories"><ul>';}
	 
				foreach ($Maincategories as $Maincat) { if(strlen($Maincat->name) > 1){ 
		 
		 
					if(is_home() && $Maincat->parent ==0){		
							
						$catlist .= '<li><span><a href="'.get_category_link( $Maincat->term_id ).'" title="'.$Maincat->category_nicename.'" style="font-size:16px; color:#454444;"><b>';
						$catlist .= $Maincat->name;
						if($SHOWCATCOUNT =="yes"){ $catlist .= " (".$Maincat->count.')</b></a></span>'; }else{ $catlist .= '</b></a></span>'; }
						//$catlist .= '</span></a>';		
	
							if($SHOW_SUBCATS == "yes"){
							
								$categories= get_categories('child_of='.$Maincat->cat_ID.'&amp;depth=1&hide_empty=0&exclude='.str_replace("-","",$GLOBALS['premiumpress']['excluded_articles'])); 
								$catcount = count($categories);	
								
							 	$stopShow=0;
								$currentcat=get_query_var('cat');	
								if(count($categories) > 0){
								$catlist .= '<div style="margin-left:10px; margin-bottom:30px;">';
									foreach ($categories as $cat) { if($stopShow < 3){
										$catlist .= '<a href="'.get_category_link( $cat->term_id ).'" title="'.$cat->cat_name.'" class="sm">';
										$catlist .= $cat->cat_name;
										//if(get_option("display_categories_count") =="yes"){ $catlist .= " (".$cat->count.")"; }
										$catlist .= '</a> ';
										} $stopShow++;
									}
									$catlist .= '</div>';
								}	 
								
							}
						
						 $catlist .= '</li>';
						
					} elseif(!is_home() && isset($GLOBALS['premiumpress']['catID']) && $Maincat->category_parent == $GLOBALS['premiumpress']['catID']){
			
						$catlist .= '<li><span><a href="'.get_category_link( $Maincat->term_id ).'" title="'.$Maincat->category_nicename.'" style="font-size:16px; color:#454444;"><b>';
						$catlist .= $Maincat->name;
						if($SHOWCATCOUNT =="yes"){ $catlist .= " (".$Maincat->count.')</b></a></span>'; }else{ $catlist .= '</b></a></span>'; }
						//$catlist .= '</span></a>';
						
							if($SHOW_SUBCATS == "yes"){
							
								$categories= get_categories('child_of='.$Maincat->cat_ID.'&amp;depth=1&hide_empty=0&exclude='.str_replace("-","",$GLOBALS['premiumpress']['excluded_articles'])); 
								$catcount = count($categories);	
								
							 
								$currentcat=get_query_var('cat');	
								if(count($categories) > 0){
								$catlist .= '<div style="margin-left:10px; margin-bottom:30px;">';
									foreach ($categories as $cat) {
										$catlist .= '<a href="'.get_category_link( $cat->term_id ).'" class="sm">';
										$catlist .= $cat->cat_name;
										//if(get_option("display_categories_count") =="yes"){ $catlist .= " (".$cat->count.")"; }
										$catlist .= '</a> ';
									}
									$catlist .= '</div>';
								}	 
								
							}					
						
						
						
						
						$catlist .= '</li>';
			
					}
				}
			}
		
	
			if($Maincatcount > 0){ $catlist .= '</ul><div class="clearfix"></div></div>'; }
	
			echo $catlist;
	
			}	
		 
	
	}	 
	 
 
 
}	



/* ============================= PREMIUM PRESS REGISTER WIDGETS ========================= */
 

if ( function_exists('register_sidebar') ){


register_sidebar(array('name'=>'Right Sidebar',
	'before_widget' => '<div class="itembox">',
	'after_widget' 	=> '</div></div>',
	'before_title' 	=> '<h2>',
	'after_title' 	=> '</h2><div class="itemboxinner widget">',
));

register_sidebar(array('name'=>'Left Sidebar (3 Column Layouts Only)',
	'before_widget' => '<div class="itembox">',
	'after_widget' 	=> '</div></div>',
	'before_title' 	=> '<h2>',
	'after_title' 	=> '</h2><div class="itemboxinner widget">',
));

register_sidebar(array('name'=>'Listing Page Sidebar',
	'before_widget' => '<div class="itembox">',
	'after_widget' 	=> '</div></div>',
	'before_title' 	=> '<h2>',
	'after_title' 	=> '</h2><div class="itemboxinner widget">',
));

register_sidebar(array('name'=>'Pages Sidebar',
	'before_widget' => '<div class="itembox">',
	'after_widget' 	=> '</div></div>',
	'before_title' 	=> '<h2>',
	'after_title' 	=> '</h2><div class="itemboxinner widget">',
));

register_sidebar(array('name'=>'Article/FAQ Page Sidebar',
	'before_widget' => '<div class="itembox">',
	'after_widget' 	=> '</div></div>',
	'before_title' 	=> '<h2>',
	'after_title' 	=> '</h2><div class="itemboxinner widget">',
));

register_sidebar(array('name'=>'Footer Left Block (1/3)',
	'before_widget' => '',
	'after_widget' 	=> '',
	'before_title' 	=> '<h3>',
	'after_title' 	=> '</h3>',
	'description' => 'This is left footer block, the footer sections is split into 3 blocks each of roughtly 300px width. ',
));

register_sidebar(array('name'=>'Footer Middle Block (2/3)',
	'before_widget' => '',
	'after_widget' 	=> '',
	'before_title' 	=> '<h3>',
	'after_title' 	=> '</h3>',
	'description' => 'This is middle footer block, the footer sections is split into 3 blocks each of roughtly 300px width. ',
));

register_sidebar(array('name'=>'Footer Right Block (3/3)',
	'before_widget' => '',
	'after_widget' 	=> '',
	'before_title' 	=> '<h3>',
	'after_title' 	=> '</h3>',
	'description' => 'This is right footer block, the footer sections is split into 3 blocks each of roughtly 300px width. ',
));
  
} 
 
 
 
 
 
 /* ============================= OLD DIRECTORYPRESS FUNCTIONS ========================= */

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 

 
	function SidebarCategories($type=0){
	
			$catlist="";
			$TabsCat = get_option("display_tabbed_cats");
	 		$catCount = get_option("display_categories_count");
			$catCount1 = get_option("display_categories_count_inner");
			$Maincategories= get_categories('pad_counts=1&use_desc_for_title=1&hide_empty=0&hierarchical=0&exclude='.str_replace("-","",$GLOBALS['premiumpress']['excluded_articles'].",".$GLOBALS['premiumpress']['excluded_articles']));
			
			$Maincatcount = count($Maincategories);	 
	
			$i=1;
			foreach ($Maincategories as $Maincat) { if(strlen($Maincat->name) > 1){ 
	 
			if($Maincat->parent ==0){
			
	
					$categories= get_categories('child_of='.$Maincat->cat_ID.'&amp;depth=1&hide_empty=0&exclude='.str_replace("-","",$GLOBALS['premiumpress']['excluded_articles']).",".str_replace("-","",$GLOBALS['premiumpress']['excluded_articles'])); 
					$catcount = count($categories);	
					
					if($TabsCat =="yes"){
						if($catcount ==0){ 
							$ThisLink = get_category_link( $Maincat->term_id );   $class="";
						}else{
							$ThisLink = "javascript:toggleLayer('DropList".$i."')";   $class="AA";
						}
					}else{
						$ThisLink = get_category_link( $Maincat->term_id );   $class="";
					}
	
					$ThisClass = ($i == count($Maincategories) - 1) ? '' : ''; //last
					$catlist .= '<li class="'.$ThisClass.$class.'">  <a href="'.$ThisLink.'" title="'.$Maincat->category_nicename.'">';
					$catlist .= $Maincat->name;
					if($catCount =="yes"){ $catlist .= " (".$Maincat->count.")"; }
					$catlist .= '</a>';
								 
			
					// do sub cats
					$currentcat=get_query_var('cat');				

					if(count($categories) > 0){
					$catlist .="<ul id='DropList".$i."' style='display:none;'>";
					if($class == "AA"){ 
						$catlist .= "<li class='sub'><a href='".get_category_link( $Maincat->term_id )."'>".$Maincat->name;
						if($catCount1 =="yes"){ $catlist .= " (".$Maincat->count.")"; }
						$catlist .=  "</a></li>"; 
					}
						foreach ($categories as $cat) {		
					
							$catlist .= '<li class="sub '.$ThisClass.'"> <a href="'.get_category_link( $cat->term_id ).'">';
							$catlist .= $cat->cat_name;
							if($catCount1 =="yes"){ $catlist .= " (".$cat->count.")"; }
							$catlist .= '</a></li>';
							 
							$i++;		
						}
					 $catlist .="</ul>";
					}
		
				$catlist .= '</li>';
				$i++;
			} 
	 } }
	return $catlist;
	
	}

   
?>