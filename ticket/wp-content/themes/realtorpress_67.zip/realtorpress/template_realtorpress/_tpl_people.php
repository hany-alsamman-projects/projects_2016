<?php get_header(); ?>

<style>.avatar,.photo { float:left; padding-right:10px;max-width:70px; max-height:70px; } .username { font-size:18px; height:30px;} .authorbtn { padding:8px; font-weight:bold;background:#ddd;  color:#333;}</style>

 
  
<div class="middleSidebar left">

<?php echo $PPTDesign->GL_ALERT($GLOBALS['error_msg'],$GLOBALS['error_type']); ?>
                   
                    
                    
<h1>Our Agents</h1>
   <div class="full clearfix border_t box"> 
 
<?php


$wp_user_search = $wpdb->get_results("SELECT ID FROM $wpdb->users ORDER BY ID");
foreach ( $wp_user_search as $userid ) {

	$user 			= new WP_User($userid->ID);	
	$ADD = explode("**",$user->jabber);		
	$r = $user->roles;
	$r = array_shift($r);	
		
	if($r =="contributor"){
 
 
 ?>
 
 
 
 <div style="background:#efefef; border:1px solid #ddd;padding:20px; float:left; width:250px; margin-right:20px; margin-top:30px; min-height:250px;">
 
 
  <a href="<?php echo get_author_posts_url( $user->post_author, $user->user_nicename ); ?>" title="<?php echo $user->user_nicename; ?>">
  	<?php if(function_exists('userphoto') && userphoto_exists($user->ID)){ echo userphoto($user->ID); }else{ echo get_avatar($user->ID,52); } ?>
  </a> 
                     
  <div class="username"><?php echo $user->user_nicename; ?></div>
  
  <p><b><em><?php echo $user->first_name; ?>  <?php echo $user->last_name; ?></em></b></p>
           
   <p><?php echo substr($user->user_description,0,200); ?>..</p> 
                
   <p><?php echo $ADD[0]; ?></p> 
              	
               
    <a href="<?php echo get_author_posts_url( $user->post_author, $user->user_nicename ); ?>" title="<?php echo $user->user_nicename; ?>" class="authorbtn">view profile</a> <a href="<?php echo get_option("messages_url"); ?>/?u=<?php echo $user->user_nicename; ?>" title="contact <?php echo $user->user_nicename; ?>" class="authorbtn">contact <?php echo $user->user_nicename; ?></a>
    
 <div class="clearfix"></div> 
  
 </div>
 
 
 
 
 
<?php }  } ?> 
 
</div> 

</div>  

 

<?php get_footer(); ?>