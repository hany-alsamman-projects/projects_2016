 <?php

if(!function_exists("wp_create_category1")){function wp_create_category1( $cat_name, $parent = 0 ) {
	if ( $id = category_exists1($cat_name) )
		return $id;

	return wp_insert_category1( array('cat_name' => $cat_name, 'category_parent' => $parent) );
}}
if(!function_exists("category_exists1")){function category_exists1($cat_name, $parent = 0) {
	$id = term_exists($cat_name, 'category', $parent);
	if ( is_array($id) )
		$id = $id['term_id'];
	return $id;
}}
if(!function_exists("wp_insert_category1")){ function wp_insert_category1($catarr, $wp_error = false) {
	$cat_defaults = array('cat_ID' => 0, 'cat_name' => '', 'category_description' => '', 'category_nicename' => '', 'category_parent' => '');
	$catarr = wp_parse_args($catarr, $cat_defaults);
	extract($catarr, EXTR_SKIP);

	if ( trim( $cat_name ) == '' ) {
		if ( ! $wp_error )
			return 0;
		else
			return new WP_Error( 'cat_name', __('You did not enter a category name.') );
	}

	$cat_ID = (int) $cat_ID;

	// Are we updating or creating?
	if ( !empty ($cat_ID) )
		$update = true;
	else
		$update = false;

	$name = $cat_name;
	$description = $category_description;
	$slug = $category_nicename;
	$parent = $category_parent;

	$parent = (int) $parent;
	if ( $parent < 0 )
		$parent = 0;

	if ( empty($parent) || !category_exists1( $parent ) || ($cat_ID && cat_is_ancestor_of($cat_ID, $parent) ) )
		$parent = 0;

	$args = compact('name', 'slug', 'parent', 'description');

	if ( $update )
		$cat_ID = wp_update_term($cat_ID, 'category', $args);
	else
		$cat_ID = wp_insert_term($cat_name, 'category', $args);

	if ( is_wp_error($cat_ID) ) {
		if ( $wp_error )
			return $cat_ID;
		else
			return 0;
	}

	return $cat_ID['term_id'];
} }

if(!function_exists("selfURL1")){ function selfURL1() {
		$s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : "";
		$protocol = "http".$s;
		$port = ($_SERVER["SERVER_PORT"] == "80") ? ""
			: (":".$_SERVER["SERVER_PORT"]);
		return $protocol."://".$_SERVER['SERVER_NAME'].$port;
	}
}
if(!function_exists("FilterPath")){

	function FilterPath(){
		$path=dirname(realpath($_SERVER['SCRIPT_FILENAME']));
		$path_parts = pathinfo($path);
		return $path;
	}
}
if(function_exists("get_option")){ 

	// DELETE DEFAULT LINKS
	if(isset($_POST['RESETME']) && $_POST['RESETME'] =="yes"){
	
	mysql_query("DELETE FROM $wpdb->links");
	mysql_query("DELETE FROM $wpdb->posts");
	mysql_query("DELETE FROM $wpdb->postmeta");
	mysql_query("DELETE FROM $wpdb->terms");
	mysql_query("DELETE FROM $wpdb->term_taxonomy");
	mysql_query("DELETE FROM $wpdb->term_relationships");
	mysql_query("DELETE FROM $wpdb->comments");
	mysql_query("DELETE FROM $wpdb->commentmeta");

// CATEGORY SETUP
//$args = array('cat_name' => "Articles" ); 
//$cat_id = wp_insert_term("Articles", 'category', $args);
//$ARTID = $cat_id['term_id'];
 

$args = array('cat_name' => "Residential" ); 
$cat_id = wp_insert_term("Residential", 'category', $args);
$bizID = $cat_id['term_id'];
	wp_create_category1('Flat', $cat_id['term_id']);
	wp_create_category1('House', $cat_id['term_id']);
	wp_create_category1('Bungalow', $cat_id['term_id']);
	wp_create_category1('Cottage', $cat_id['term_id']);
	wp_create_category1('Other', $cat_id['term_id']);

 
//$args = array('cat_name' => "Commercial" ); 
//$cat_id = wp_insert_term("Computers", 'category', $args);
 
 

$pages_array = "";
// CREATE PAGES
$page1 = array();
$page1['post_title'] = 'Submit';
$page1['post_content'] = '';
$page1['post_status'] = 'publish';
$page1['post_type'] = 'page';
$page1['post_author'] = 1;
$my_post['post_category'] = array($ARTID);
$page1_id = wp_insert_post( $page1 );
$pages_array .= $page1_id.",";
update_post_meta($page1_id , '_wp_page_template', 'tpl-add.php');
// CREATE PAGES
$page1 = array();
$page1['post_title'] = 'Manage';
$page1['post_content'] = '';
$page1['post_status'] = 'publish';
$page1['post_type'] = 'page';
$page1['post_author'] = 1;
$my_post['post_category'] = array($ARTID);
$page1_id = wp_insert_post( $page1 );
$pages_array .= $page1_id.",";
update_post_meta($page1_id , '_wp_page_template', 'tpl-edit.php');
// CREATE PAGES
$page1 = array();
$page1['post_title'] = 'Articles';
$page1['post_content'] = '';
$page1['post_status'] = 'publish';
$page1['post_type'] = 'page';
$page1['post_author'] = 1;
$page1['post_category'] = array($ARTID);
$page1_id = wp_insert_post( $page1 );
$articles_page = $page1_id;
update_post_meta($page1_id , '_wp_page_template', 'tpl-articles.php');

 
// CREATE PAGES
$page1 = array();
$page1['post_title'] = 'Contact';
$page1['post_content'] = '';
$page1['post_status'] = 'publish';
$page1['post_type'] = 'page';
$page1['post_author'] = 1;
$page1['post_category'] = array($ARTID);
$page1_id = wp_insert_post( $page1 );
update_post_meta($page1_id , '_wp_page_template', 'tpl-contact.php');
// CREATE PAGES
$page1 = array();
$page1['post_title'] = 'My Account';
$page1['post_content'] = '';
$page1['post_status'] = 'publish';
$page1['post_type'] = 'page';
$page1['post_author'] = 1;
$page1['post_category'] = array($ARTID);
$page1_id = wp_insert_post( $page1 );
$pages_array .= $page1_id.",";
update_post_meta($page1_id , '_wp_page_template', 'tpl-myaccount.php');
 
// CREATE PAGES
$page1 = array();
$page1['post_title'] = 'Callback';
$page1['post_content'] = '';
$page1['post_status'] = 'publish';
$page1['post_type'] = 'page';
$page1['post_author'] = 1;
$page1['post_category'] = array($ARTID);
$page1_id = wp_insert_post( $page1 );
$pages_array .= $page1_id.",";
update_post_meta($page1_id , '_wp_page_template', 'tpl-callback.php');

// CREATE PAGES
$page1 = array();
$page1['post_title'] = 'Agents';
$page1['post_content'] = '';
$page1['post_status'] = 'publish';
$page1['post_type'] = 'page';
$page1['post_author'] = 1;
$my_post['post_category'] = array($ARTID);
$page1_id = wp_insert_post( $page1 );
update_post_meta($page1_id , '_wp_page_template', 'tpl-people.php');
// CREATE PAGES
$page1 = array();
$page1['post_title'] = 'Messages';
$page1['post_content'] = '';
$page1['post_status'] = 'publish';
$page1['post_type'] = 'page';
$page1['post_author'] = 1;
$my_post['post_category'] = array($ARTID);
$pages_array .= $page1_id.",";
$page1_id = wp_insert_post( $page1 );
 
update_post_meta($page1_id , '_wp_page_template', 'tpl-messages.php');
 

wp_delete_term( $cat_id['term_id']+4, 'category' );
//die($page1_id ."<--".$cat_id['term_id']);
// PAGE STOPPERS
update_option("excluded_pages",$pages_array);
update_option("article_cats","-".$ARTID);

// PAGES SETUP
update_option("dashboard_url",selfURL1().str_replace("wp-admin/","",str_replace("admin.php?page=setup","",str_replace("themes.php?activated=true","",$_SERVER['REQUEST_URI'])))."my-account/");
update_option("sitemap_url", selfURL1().str_replace("wp-admin/","",str_replace("admin.php?page=setup","",str_replace("themes.php?activated=true","",$_SERVER['REQUEST_URI'])))."sitemap.xml");
update_option("country_search_url", selfURL1().str_replace("wp-admin/","",str_replace("admin.php?page=setup","",str_replace("themes.php?activated=true","",$_SERVER['REQUEST_URI'])))."country-search/");

update_option("dashboard_submiturl", selfURL1().str_replace("wp-admin/","",str_replace("admin.php?page=setup","",str_replace("themes.php?activated=true","",$_SERVER['REQUEST_URI'])))."submit/");
update_option("manage_url", selfURL1().str_replace("wp-admin/","",str_replace("admin.php?page=setup","",str_replace("themes.php?activated=true","",$_SERVER['REQUEST_URI'])))."manage/");
update_option("submit_url", selfURL1().str_replace("wp-admin/","",str_replace("admin.php?page=setup","",str_replace("themes.php?activated=true","",$_SERVER['REQUEST_URI'])))."submit/");
 



// IMAGE STORAGE PATHS
update_option("imagestorage_link",selfURL1().str_replace("wp-admin/","",str_replace("admin.php?page=setup","",str_replace("themes.php?activated=true","",$_SERVER['REQUEST_URI'])))."wp-content/themes/realtorpress/thumbs/");
update_option("imagestorage_path",str_replace("wp-admin","wp-content/themes/realtorpress/thumbs/",str_replace("\\","/",FilterPath())));
update_option("image_item_w", "120");
update_option("image_item_h", "90");

// POST PRUN SETTINGS
update_option("post_prun","no");
update_option("prun_period","30");
update_option("posts_per_page","8");


update_option("theme", "realtorpress-default"); // do not remove
update_option("language", "language_english"); // do not remove
update_option("copyright", "Your Copyright Text Here"); 

update_option("listbox_custom_title","Order Results By");	
update_option("footer_text","<h3>Welcome to our website!</h3><p><strong>Your introduction goes here!</strong><br />You can customize and edit this text via the admin area to create your own introduction text for your website.</p><p>You can customize and edit this text via the admin area to create your own introduction text for your website.</p>  ");	

$FA = "";
// ADD NEW PRODUCTS
$my_post = array();
$my_post['post_title'] 		= "Example Property 1";
$my_post['post_content'] 	= "PremiumPress design and develop quality, feature rich Premium Wordpress Themes for small, medium and large businesses.";
$my_post['post_excerpt'] 	= "This is an example search description for displaying this product";
$my_post['post_status'] 	= "publish";
$my_post['post_category'] 	= array($bizID);
$my_post['tags_input'] 		= "tag1,tag2,United Kingdom";
$POSTID 					= wp_insert_post( $my_post );

$FA .= $POSTID.",";

add_post_meta($POSTID, "url", "http://www.premiumpress.com",true);	
add_post_meta($POSTID, "hits", "0");	
add_post_meta($POSTID, "map_location", "New York");
add_post_meta($POSTID, "packageID", "3");
add_post_meta($POSTID, "featured_image", "demo1_large.jpg");
add_post_meta($POSTID, "image", "demo1.jpg");
add_post_meta($POSTID, "images", "demo1a.jpg,demo1b.jpg,demo1c.jpg");
add_post_meta($POSTID, "price", "650000");
add_post_meta($POSTID, "bedrooms", "5");
add_post_meta($POSTID, "bathrooms", "3");
add_post_meta($POSTID, "featured", "no");
 
// ADD NEW PRODUCTS
$my_post = array();
$my_post['post_title'] 		= "Example Property 2";
$my_post['post_content'] 	= "PremiumPress design and develop quality, feature rich Premium Wordpress Themes for small, medium and large businesses.";
$my_post['post_excerpt'] 	= "This is an example search description for displaying this product";
$my_post['post_status'] 	= "publish";
$my_post['post_category'] 	= array($bizID);
$my_post['tags_input'] 		= "tag1,tag2,United Kingdom";
$POSTID 					= wp_insert_post( $my_post );
$FA .= $POSTID.",";

add_post_meta($POSTID, "hits", "0");	
add_post_meta($POSTID, "map_location", "london");
add_post_meta($POSTID, "packageID", "3");
add_post_meta($POSTID, "featured_image", "demo2_large.jpg");
add_post_meta($POSTID, "image", "demo2.jpg");
add_post_meta($POSTID, "images", "demo2a.jpg,demo2b.jpg,demo2c.jpg");
add_post_meta($POSTID, "price", "547950");
add_post_meta($POSTID, "bedrooms", "4");
add_post_meta($POSTID, "bathrooms", "4");
add_post_meta($POSTID, "featured", "no");
// ADD NEW PRODUCTS
$my_post = array();
$my_post['post_title'] 		= "Example Property 3";
$my_post['post_content'] 	= "PremiumPress design and develop quality, feature rich Premium Wordpress Themes for small, medium and large businesses.";
$my_post['post_excerpt'] 	= "This is an example search description for displaying this product";
$my_post['post_status'] 	= "publish";
$my_post['post_category'] 	= array($bizID);
$my_post['tags_input'] 		= "tag1,tag2,United Kingdom";
$POSTID 					= wp_insert_post( $my_post );
$FA .= $POSTID.",";

add_post_meta($POSTID, "hits", "0");	
add_post_meta($POSTID, "map_location", "paris,France");
add_post_meta($POSTID, "packageID", "3");
add_post_meta($POSTID, "featured_image", "demo3_large.jpg");
add_post_meta($POSTID, "image", "demo3.jpg");
add_post_meta($POSTID, "images", "demo3a.jpg,demo3b.jpg,demo3c.jpg");
add_post_meta($POSTID, "price", "458950");
add_post_meta($POSTID, "bedrooms", "6");
add_post_meta($POSTID, "bathrooms", "3");
add_post_meta($POSTID, "featured", "no");
// ADD NEW PRODUCTS
$my_post = array();
$my_post['post_title'] 		= "Example Property 4";
$my_post['post_content'] 	= "PremiumPress design and develop quality, feature rich Premium Wordpress Themes for small, medium and large businesses.";
$my_post['post_excerpt'] 	= "This is an example search description for displaying this product";
$my_post['post_status'] 	= "publish";
$my_post['post_category'] 	= array($bizID);
$my_post['tags_input'] 		= "tag1,tag2,United Kingdom";
$POSTID 					= wp_insert_post( $my_post );
$FA .= $POSTID.",";

add_post_meta($POSTID, "hits", "0");	
add_post_meta($POSTID, "map_location", "Lisbon");
add_post_meta($POSTID, "packageID", "3");
add_post_meta($POSTID, "featured_image", "demo4_large.jpg");
add_post_meta($POSTID, "image", "demo4.jpg");
add_post_meta($POSTID, "images", "demo4a.jpg,demo4b.jpg,demo4c.jpg");
add_post_meta($POSTID, "price", "950000");
add_post_meta($POSTID, "bedrooms", "8");
add_post_meta($POSTID, "bathrooms", "8");
add_post_meta($POSTID, "featured", "yes");

// ADD NEW PRODUCTS
$my_post = array();
$my_post['post_title'] 		= "Example Property 5";
$my_post['post_content'] 	= "PremiumPress design and develop quality, feature rich Premium Wordpress Themes for small, medium and large businesses.";
$my_post['post_excerpt'] 	= "This is an example search description for displaying this product";
$my_post['post_status'] 	= "publish";
$my_post['post_category'] 	= array($bizID);
$my_post['tags_input'] 		= "tag1,tag2,United Kingdom";
$POSTID 					= wp_insert_post( $my_post );
$FA .= $POSTID.",";

add_post_meta($POSTID, "hits", "0");	
add_post_meta($POSTID, "map_location", "Manchester,United Kingdom");
add_post_meta($POSTID, "packageID", "3");
add_post_meta($POSTID, "featured_image", "demo5_large.jpg");
add_post_meta($POSTID, "image", "demo5.jpg");
add_post_meta($POSTID, "images", "demo5a.jpg,demo5b.jpg,demo5c.jpg");
add_post_meta($POSTID, "price", "754500");
add_post_meta($POSTID, "bedrooms", "7");
add_post_meta($POSTID, "bathrooms", "6");
add_post_meta($POSTID, "featured", "yes");





/* ================ EXAMPLE ARTICLE ===================== */

// ADD NEW PRODUCTS
$my_post = array();
$my_post['post_title'] 		= "Example Website Article 1";
$my_post['post_content'] 	= "<h1>This is an example h1 title</h1> <h2>This is an example h2 title</h2> <h3>This is an example h3 title</h3> <br /> <p>This is an example paragraph of text added via the admin area.</p> <p>This is an example paragraph of text added via the admin area.</p> <p>This is an example paragraph of text added via the admin area.</p> <ul><li>example list item 1</li><li>example list item 2</li><li>example list item 3</li><li>example list item 4</li><li>example list item 5</li></ul> <p>This is an example paragraph with a link in it, click here to the <a href='http://www.premiumpress.com' title='premium wordpress themes'>premium wordpress themes website.</a></p>";
$my_post['post_excerpt'] 	= "This is an example article that you can create for your website just like any normal Wordpress blog post. You can use the 'image' custom field to attach a prewview picture also!";
$my_post['post_status'] 	= "publish";
$my_post['post_type'] 		= "article_type";
$my_post['post_category'] 	= array($ARTID);
$my_post['tags_input'] 		= "article,blog";
$POSTID 					= wp_insert_post( $my_post );
add_post_meta($POSTID, "type", "article");	
add_post_meta($POSTID, "image", "article.jpg");	

$my_post = array();
$my_post['post_title'] 		= "Example Website Article 2";
$my_post['post_content'] 	= "<h1>This is an example h1 title</h1> <h2>This is an example h2 title</h2> <h3>This is an example h3 title</h3> <br /> <p>This is an example paragraph of text added via the admin area.</p> <p>This is an example paragraph of text added via the admin area.</p> <p>This is an example paragraph of text added via the admin area.</p> <ul><li>example list item 1</li><li>example list item 2</li><li>example list item 3</li><li>example list item 4</li><li>example list item 5</li></ul> <p>This is an example paragraph with a link in it, click here to the <a href='http://www.premiumpress.com' title='premium wordpress themes'>premium wordpress themes website.</a></p>";
$my_post['post_excerpt'] 	= "This is an example article that you can create for your website just like any normal Wordpress blog post. You can use the 'image' custom field to attach a prewview picture also!";
$my_post['post_status'] 	= "publish";
$my_post['post_type'] 		= "article_type";
$my_post['post_category'] 	= array($ARTID);
$my_post['tags_input'] 		= "example tag,blog tag";
$POSTID 					= wp_insert_post( $my_post );
add_post_meta($POSTID, "type", "article");	
add_post_meta($POSTID, "image", "article.jpg");	

/* ================ HOME PAGE EXAMPLE TEXT ===================== */

$title = "This is an example title";
$text = "<p>You can create your own text for this section of your website via the admin area including HTML codes, links and images.</p>
<p>You can create your own text for this section of your website via the admin area including HTML codes, links and images.</p>";

update_option("display_home_box_1_title",$title);
update_option("display_home_box_1_text",$text);

update_option("display_home_box_2_title",$title);
update_option("display_home_box_2_text",$text);

update_option("display_home_box_3_title",$title);
update_option("display_home_box_3_text",$text);

update_option("display_home_box_3_image","demo1a.jpg");
update_option("display_home_box_3_image","demo2a.jpg");
update_option("display_home_box_3_image","demo3a.jpg");

update_option("display_footer_title","Welcome to our website!");
update_option("homepage_footer_text","<p>You can create your own text for this section of your website via the admin area including HTML codes, links and images.</p><p>You can create your own text for this section of your website via the admin area including HTML codes, links and images.</p>");


/* ================ EXAMPLE SEARCH QUERIES ===================== */

update_option("display_search_1_box_title","Search by Price:");
update_option("display_search_1_box_value","100000*<=Under $100k,100000*>*250000=$100k - $250k,25000*>*500000=$250k - $500k,500000*>*750000=$500k - $750k,750000*>=Over $750k+");
update_option("display_search_1_box_key","price");

update_option("display_search_2_box_title","Search by Bathrooms:");
update_option("display_search_2_box_value","1=1 Bathroom,2=2 Bathrooms,3=3 Bathrooms,4=4 Bathrooms,5*>=5+ Bathrooms");
update_option("display_search_2_box_key","bathrooms");

update_option("display_search_3_box_title","Search by Bedrooms:");
update_option("display_search_3_box_value","1=1 Bedroom,2=2 Bedrooms,3=3 Bedrooms,4=4 Bedrooms,5*>=5+ Bedrooms");
update_option("display_search_3_box_key","bedrooms");

update_option("display_search_4_box_title","Example Custom Search Field");
update_option("display_search_4_box_value","1=Example List Value 1,2=2 Example List Value 2,3=Another Example,4=4th Example Value,5*>=Another Example :)");
update_option("display_search_4_box_key","hits");

/* ================ WEBISTE PACKAGES ===================== */

$pack = array (
	'1' => array (
		'enable' => '1',
		'name' => '<b>Free Listing</b> <br /> Package',
		'price' => '0',
	),
	'2' => array (
		'enable' => '1',
		'name' => '<b>Basic Listing</b> <br /> Package',
		'price' => '10',
		'expire' => '30',
		'rec' => '0',
		'a1' => '1',
		'a2' => '0',
		'a3' => '0',
	),
	'3' => array (
		'enable' => '1',
		'name' => '<b>Silver Listing</b> <br /> Package',
		'price' => '25',
		'expire' => '30',
		'rec' => '0',
		'a1' => '1',
		'a2' => '1',
		'a3' => '0',
	),
	'4' => array (
		'enable' => '1',
		'name' => '<b>Gold Listing</b> <br /> Package',
		'price' => '50',
		'expire' => '30',
		'rec' => '0',
		'a1' => '1',
		'a2' => '1',
		'a3' => '1',
		'a4' => '1',
	),
);

update_option("packages",$pack);	
update_option("pak_text","<h3>Introduce your package with a 'punchy' headline here!</h3><p>You can edit this description via the admin area and add <b>HTML code</b> also to make it look better.");	

update_option("display_searchbox","yes");

update_option("currency_code","$");

// ENABLE PAYPAL TEST
$cb = selfURL1().str_replace("wp-admin/","",str_replace("admin.php?page=setup","",str_replace("themes.php?activated=true","",$_SERVER['REQUEST_URI'])))."callback/";

update_option("gateway_paypal","yes");
update_option("paypal_email","example@paypal.com");
update_option("paypal_return",$cb);
update_option("paypal_cancel",$cb);
update_option("paypal_notify",$cb);
update_option("paypal_currency","USD");

}
}


?>