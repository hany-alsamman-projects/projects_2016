<?php 
/*
LAST UPDATED: 27th March 2011
EDITED BY: MARK FAIL
*/ 
 
$GLOBALS['singleCategory'] 	= get_the_category($post->ID); 

get_header();

// SETUP GLOBAL VALUES FROM CUSTOM DATA
$GLOBALS['images'] 		= get_post_meta($post->ID, 'images', true);
$GLOBALS['map'] 		= get_post_meta($post->ID, "map_location", true);
$GLOBALS['price'] 		= get_post_meta($post->ID, 'price', true);
$GLOBALS['thisID'] 		= $post->ID;
$GLOBALS['listtype'] 	= get_post_meta($post->ID, 'listtype', true);
$GLOBALS['beds'] 		= get_post_meta($post->ID, "bedrooms", true);
$GLOBALS['baths'] 		= get_post_meta($post->ID, "bathrooms", true);

if($GLOBALS['listtype'] == ""){ $GLOBALS['listtype']	= "sale"; }

$CustomFields 	= get_option("customfielddata");

if (have_posts()) : while (have_posts()) : the_post();  ?>

<div class="col b1 first_col"> 



<?php echo $PPTDesign->GL_ALERT($GLOBALS['error_msg'],$GLOBALS['error_type']); ?>






 

     
    <div id="ImageBorder">
    
    <div id="SingleLabel" class="<?php echo $GLOBALS['listtype']; ?>"> 
    
        <ul>
        <li class="price"><?php echo $PPT->Price(get_post_meta($post->ID, "price", true),$GLOBALS['premiumpress']['currency_symbol'],$GLOBALS['premiumpress']['currency_position'],1); ?></li>
        <li><?php echo $GLOBALS['beds']; ?> <?php echo SPEC($GLOBALS['_LANG']['_bedrooms']) ?></li>
        <li><?php echo $GLOBALS['baths']; ?> <?php echo SPEC($GLOBALS['_LANG']['_bathrooms']) ?></li>     
        </ul>
     
    </div>  
    
    
    <div id="SingleImgPlace" style="padding:20px;display:center;">  <img src="<?php echo $PPT->Image($post,"full"); ?>" alt="<?php the_title(); ?>" style="max-width:600px !important; " /></div>    

    </div>
    
 	<?php if(get_option("display_social") =="yes"){ ?>
 
     <div class="addthis_toolbox">
				<div class="hover_effect">
					<div><a class="addthis_button_email"> &nbsp;<?php echo SPEC($GLOBALS['_LANG']['_single12']) ?></a></div>
					<div style="margin-right:320px;"><a class="addthis_button_print"> &nbsp;<?php echo SPEC($GLOBALS['_LANG']['_single13']) ?></a></div>
					<div><a class="addthis_button_twitter">&nbsp;</a></div>
					<div><a class="addthis_button_facebook">&nbsp;</a></div>
					<div><a class="addthis_button_myspace">&nbsp;</a></div>
					<div><a class="addthis_button_digg">&nbsp;</a></div>
					<div><a class="addthis_button_expanded">&nbsp;</a></div>
					<div style="clear:both; float:none;"></div> 
				</div>
			</div>  
  
    	<?php } ?>     
   

		   
    
    
    
    <?php $imgAa = explode(",",$GLOBALS['images']); if(isset($imgAa[1]) && strlen($GLOBALS['images']) > 5 ){ ?>
    
    <div id="style2_wrapper"><div id="style2" class="style2"><div class="previous_button"></div><div class="container"><ul>

    <?php
		 
	foreach ($imgAa as $img){ if(strlen($img) > 2){  ?>
	<li>
	<a href="#" onClick="changeProperty1('<?php echo trim($img); ?>','SingleImgPlace');">
		<img src="<?php echo $PPT->ImageCheck(trim($img),"t"); ?>" width="120" height="90" style="cursor:pointer;" alt="<?php echo $img ?>" />
	</a>	 
	</li>
	<?php } }  ?>	

    </ul></div><div class="next_button"></div></div>
    </div>
    
    <script src="<?php echo PPT_PATH; ?>js/jquery.jcarousel.pack.js" type="text/javascript"></script>
    <script src="<?php echo PPT_PATH; ?>js/jquery.jcarousellite_1.0.1.js" type="text/javascript"></script>
    <script type="text/javascript">
    jQuery(function() {    jQuery(".style2").jCarouselLite({        btnNext: ".next_button",        btnPrev: ".previous_button",		visible: 3,		scroll: 1, auto:18000    }); });
    </script>
	
	<?php } ?>

    
    
    
    
    
    
    
    
    
    
    
    
    
    
 	<div class="clearfix"></div>

    <ul class="tabs"> 
        
            <li><a href="#info" id="icon-single-info"><?php echo SPEC($GLOBALS['_LANG']['_single3']) ?></a></li> 
            
             
            <?php if(get_option("display_single_comments") =="yes"){ ?><li><a href="#comments" id="icon-single-comment">
			<?php  comments_number($GLOBALS['_LANG']['_nocomments'], $GLOBALS['_LANG']['_1comment'], '% '.$GLOBALS['_LANG']['_comments']); ?></a></li>			
            <?php  } ?> 
            
            <?php if(get_option("display_contactform") =="yes2"){ ?> <li><a href="#contact" id="icon-single-contact"><?php echo SPEC($GLOBALS['_LANG']['_single5']) ?></a></li><?php } ?>
             
    </ul> 
    
    
    <div class="tab_container"> 
    
      <div id="info" class="tab_content entry"> 
      
      
      		<?php  if(isset($GLOBALS['mapType']) && strlen($GLOBALS['mapType']) > 2  && $GLOBALS['mapType'] !="no" && strlen($GLOBALS['map']) > 1) {  ?>       
            
			   <?php if($GLOBALS['mapType'] == "yes1"){  ?> 
                
                <iframe id="GoogleMap" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"  style="width:240px; height:230px;float:right;"
                src="http://maps.google.com/maps/api/staticmap?zoom=15&amp;size=240x230&amp;markers=color:red|label:Here|<?php echo $GLOBALS['map']; ?>&amp;sensor=false&amp;key=<?php echo get_option("google_maps_api"); ?>">
                </iframe>          
                
                <?php }elseif($GLOBALS['mapType'] == "yes2"){ ?>            
       
                <div id="map_sidebar2" style="float:right;"></div> 
                
                <?php }   ?> 		    
 
			<?php } ?>
    
    
    	  <h1><?php the_title(); ?></h1>
      
          <?php the_content(); ?> 
          
          <div class="clearfix"></div><br />
          
          
          <div class="full clearfix border_t box"><p class="f_half left"><br /><?php echo SPEC($GLOBALS['_LANG']['_single15']) ?>  <b><?php echo $PPT->Price(get_post_meta($post->ID, "price", true),$GLOBALS['premiumpress']['currency_symbol'],$GLOBALS['premiumpress']['currency_position'],1); ?></b></p>
          <p class="f_half left"><br /><?php echo SPEC($GLOBALS['_LANG']['_single16']) ?> <b><?php the_time('l, F jS, Y') ?></b></p></div>
          
          <div class="full clearfix border_t box"><p class="f_half left"><br /><b><?php echo $GLOBALS['beds']; ?></b> <?php echo SPEC($GLOBALS['_LANG']['_bedrooms']) ?></p><p class="f_half left"><br /><b><?php echo $GLOBALS['baths']; ?></b> <?php echo SPEC($GLOBALS['_LANG']['_bathrooms']) ?></p></div>
          <div class="full clearfix border_t box"><p class="f_half left"><br /><b><?php echo SPEC($GLOBALS['_LANG']['_single14']) ?></b></p><p class="f_half left"><br /><?php echo $GLOBALS['map']; ?></p></div>
          
          <?php $ThemeDesign->SINGLE_CUSTOMFIELDS($post,$CustomFields); ?>         
          
      </div> 
 
        
        <div id="comments" class="tab_content">                
    
    		<?php comments_template();  ?>
    
    	</div>  
        
        
        <?php if(get_option("display_contactform") =="yes2"){ ?>
        
        <div id="contact" class="tab_content">                
        
        <form action="" method="post" onsubmit="return CheckMessageData(this.message_name.value,this.message_subject.value,this.message_message.value,'Please complete all fields.');"> 
        <input type="hidden" name="action" value="sidebarcontact" />
        <input type="hidden" name="message_name" value="<?php echo the_author_meta('login'); ?>" />
        <input type="hidden" name="author_ID" value="<?php echo get_the_author_id() ?>" />
        <?php wp_nonce_field('ContactForm') ?>
        <fieldset> 
                                 
            <div class="full clearfix border_t box"> 
            <p class="f_half left"> 
                <label for="name"><?php echo SPEC($GLOBALS['_LANG']['_single7']) ?><span class="required">*</span></label><br />
                <input type="text" name="message_from" id="message_name"  class="short" tabindex="1" />
            </p> 
            <p class="f_half left"> 
                <label for="email"><?php echo SPEC($GLOBALS['_LANG']['_single8']) ?><span class="required">*</span></label><br /> 
                <input type="text" name="message_subject" id="message_subject" class="short" tabindex="2" />               
            </p> 
            </div> 
     
                  
            <div class="full clearfix border_t box"> 
            <p>
                <label for="comment"><?php echo SPEC($GLOBALS['_LANG']['_single9']) ?><span class="required">*</span></label><br /> 
                <textarea tabindex="4" class="long" rows="4" name="message_message" id="message_message"></textarea> <br />                   
            </p>
            </div>   
            
            <?php $email_nr1 = rand("0", "9");$email_nr2 = rand("0", "9"); ?>
            <div class="full clearfix border_t box"> 
            <p class="f_half left"> 
                <label for="name"><?php echo SPEC(str_replace("%a",$email_nr1,str_replace("%b",$email_nr2,SPEC($GLOBALS['_LANG']['_single10'])))) ?></label><br /> 
                <input type="text" name="code" value="" class="long" tabindex="1" /><br /> 
                <input type="hidden" name="code_value" value="<?php echo $email_nr1+$email_nr2; ?>" />
            </p> 
             </div>               
            
            <div class="full clearfix border_t box"> 
            <p class="full clearfix"> 
                <input type="submit" name="submit1" class="button blue" tabindex="15" value="<?php echo SPEC($GLOBALS['_LANG']['_single11']) ?>" />  
            </p> 
            </div>	
        
        </fieldset> 
        </form>
        
    	</div>         
        <?php } ?>
         
    </div>    
      
 
	 
    
     
   
   

   
   
   
   
 
           

</div>  
		
			
 <?php get_sidebar(); ?>	
 
 <?php endwhile; else :  endif; ?>
 


<div class="clearfix"></div>  



<script type="text/javascript"> 
 
jQuery(document).ready(function() {
 
	//Default Action
	jQuery(".tab_content").hide(); //Hide all content
	jQuery("ul.tabs li:first").addClass("active").show(); //Activate first tab
	jQuery(".tab_content:first").show(); //Show first tab content
	
	//On Click Event
	jQuery("ul.tabs li").click(function() {
		jQuery("ul.tabs li").removeClass("active"); //Remove any "active" class
		jQuery(this).addClass("active"); //Add "active" class to selected tab
		jQuery(".tab_content").hide(); //Hide all tab content
		var activeTab = jQuery(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
		jQuery(activeTab).fadeIn(); //Fade in the active content
		return false;
		
	});
 
});
</script>

<?php get_footer(); ?>