<?php  

/*
LAST UPDATED: 3rd April 2011
EDITED BY: MARK FAIL
*/

$GLOBALS['mapOrImage'] = get_option("display_featured_image_enable");

if(get_option("display_home_scroller") =="yes" && $GLOBALS['mapOrImage'] != 1){ $GLOBALS['isHome'] = 1; } // USED TO TURN ON/OFF THE SCROLLER SECTION


$GLOBALS['nosidebar'] =1;  // REMOVES THE SIDEBAR

$postslist = query_posts('meta_key=featured&meta_value=yes&posts_per_page=20');	 // GETS THE POST LIST

get_header();  
 

?>


 



<?php /*--------------------- ADVANCED SEARCH BOX --------------------------- */ ?>

<form method="get"  action="<?php echo $GLOBALS['bloginfo_url']; ?>/" name="HomesearchBox" id="HomesearchBox">

<h1><?php $count_posts = wp_count_posts();  $numcats = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->term_taxonomy WHERE taxonomy='category'"); 
		echo SPEC(str_replace("%a",$count_posts->publish,str_replace("%b",number_format($numcats),$GLOBALS['_LANG']['_homepage_title']))) ?></h1>
 
<p style="font-size:20px;"><?php echo SPEC($GLOBALS['_LANG']['_homepage1']) ?> <input name="s" id="s" type="text"onfocus="this.value='';" value="<?php echo SPEC($GLOBALS['_LANG']['_homepage2']) ?>"/>

<input type="submit" value="<?php echo SPEC($GLOBALS['_LANG']['_homepage3']) ?>" style="margin-left:10px;font-size:22px;" /></p>

<?php if(get_option("display_advanced_search") ==1){ ?> <?php echo SPEC($GLOBALS['_LANG']['_homepage4']) ?> <a href="javascript:void(0);" onClick="jQuery('#AdvancedSearchBox').show();"><?php echo SPEC($GLOBALS['_LANG']['_homepage5']) ?></a> <?php } ?>
 
</form>

<?php /*----------------------------------------------------------------------*/ ?>





 



<?php if(get_option("display_home_scroller") =="yes"){ ?>




<div id="PPT-Home-Box">

	<div class="home-image">

	<?php 
    
    /*--------------------------------------------------------------------- */     
    
    if($GLOBALS['mapOrImage'] =="1"){ print "<a href='".get_option("display_featured_image_link")."'><img src='".get_option("display_featured_image_url")."' alt='featured' /></a>"; }else{ ?>    
   	
    <div id="map_homepage"></div>
    
    <?php } ?>
    
    
	</div>

 
	<div class="home-search">
		 
         <div id="home-search-info"> 
         
         <h1><?php echo $postslist[0]->post_title; ?></h1>
         
         <img src="<?php echo $PPT->Image($postslist[0],"m"); ?>" width="80" height="70" alt="<?php echo $post->post_title ?>" />
         
         <p class="title"><?php echo $PPT->Price(get_post_meta($postslist[0]->ID, "price", true),$GLOBALS['premiumpress']['currency_symbol'],$GLOBALS['premiumpress']['currency_position'],1); ?></p>
          
         <p class="desc"><?php echo substr($postslist[0]->post_excerpt,0,255); ?>..</p>         
         
         <div class="clearfix"></div>
         
         <div style="border-top:1px dotted #ccc;font-size:16px; padding-top:20px;"> 
         
         
		<ul class="item_stats" style="margin:0;">
				 
				<li class="beds"><?php echo get_post_meta($postslist[0]->ID, "bedrooms", true); ?> <?php echo SPEC($GLOBALS['_LANG']['_bedrooms']) ?></li>
                <li class="baths"><?php echo get_post_meta($postslist[0]->ID, "bathrooms", true); ?> <?php echo SPEC($GLOBALS['_LANG']['_bathrooms']) ?></li>
			</ul>        
      
         <div class="clearfix"></div>
         
          <br /><p><a href="<?php echo get_permalink($postslist[0]->ID); ?>" class="btn"><?php echo SPEC($GLOBALS['_LANG']['_homepage6']) ?></a></p>
         
         </div>
         
         </div>
         
	</div>
    
    
<div class="clearfix"></div>

</div>  

<?php



?>




<div id="style1_wrapper"><div id="style1" class="style1"><div class="previous_button"></div><div class="container"><ul>

    <?php foreach ($postslist as $post ){   ?>
	<li>
	<a href="javascript:void(0);" onclick="changeProperty('<?php echo $post->ID; ?>','home-search-info');
    <?php if($GLOBALS['mapOrImage'] !=1){ ?>ChangeAddress('<span style=color:white><?php echo str_replace("'","\'",$post->post_title); ?></span><img src=<?php echo $PPT->Image($post,"m"); ?> />','<?php echo str_replace("'","\'",get_post_meta($post->ID, "map_location", true)); ?>','<?php echo get_permalink($post->ID)?>');<?php } ?>">
		<img src="<?php echo $PPT->Image($post,"m"); ?>" width="120" height="90" style="cursor:pointer;" alt="<?php echo $post->post_title ?>" />
	</a>
	<div><?php echo $post->post_title ?> <br /> <em class="price"><?php echo $PPT->Price(get_post_meta($post->ID, "price", true),$GLOBALS['premiumpress']['currency_symbol'],$GLOBALS['premiumpress']['currency_position'],1); ?></em> </div>
	</li>
	<?php }  ?>	

</ul></div><div class="next_button"></div></div>
</div>

<script src="<?php echo PPT_PATH; ?>js/jquery.jcarousel.pack.js" type="text/javascript"></script>
<script src="<?php echo PPT_PATH; ?>js/jquery.jcarousellite_1.0.1.js" type="text/javascript"></script>
<script type="text/javascript">
jQuery(function() {    jQuery(".style1").jCarouselLite({        btnNext: ".next_button",        btnPrev: ".previous_button",		visible: 5,		scroll: 1, auto:2000    }); });
</script>






<?php } ?>
















 
<?php /*--------------------- ADVANCED SEARCH BOX --------------------------- */ ?>

<?php if(get_option("display_home_listings") =="yes"){ ?>
<div id="Home-PropertyList">

<div class="full clearfix box border_b">

    <div class="f_half left">
    
    <h1 class="border_b"><?php echo SPEC($GLOBALS['_LANG']['_homepage_ral']) ?></h1>
                
        <div class="gut">
        
            <ul class="propertylist">	
            
                <?php 
                wp_reset_query();                
                $postslist = query_posts('&order=DESC&orderby=ID&post_type=post');
                foreach ($postslist as $loopID => $p){ $post=$p;  
                    
                    if(file_exists(str_replace("functions/","",THEME_PATH)."/themes/".$GLOBALS['premiumpress']['theme'].'/_item_small.php')){
                                            
                        include(str_replace("functions/","",THEME_PATH)."/themes/".$GLOBALS['premiumpress']['theme'].'/_item_small.php');
                                            
                    }else{
                                        
                        include("_item_small.php"); 
                                    
                    }
                
                }		
                
                ?>
            
            </ul>   
        
        </div>              
    
    </div>

    <div class="f_half left">
    
    <h1 class="border_b"><?php echo SPEC($GLOBALS['_LANG']['_homepage7']) ?></h1>
    
        <ul class="propertylist">	
        
            <?php 
			$GLOBALS['key'] = 'hits';
            wp_reset_query();                
            $postslist = query_posts('order=meta_value_num&orderby=meta_value&meta_key=hits&post_type=post');
            foreach ($postslist as $loopID => $p){ $post=$p;  
                
                if(file_exists(str_replace("functions/","",THEME_PATH)."/themes/".$GLOBALS['premiumpress']['theme'].'/_item_small.php')){
                                        
                    include(str_replace("functions/","",THEME_PATH)."/themes/".$GLOBALS['premiumpress']['theme'].'/_item_small.php');
                                        
                }else{
                                    
                    include("_item_small.php"); 
                                
                }
            
            }		
            
            ?>
        
        </ul> 
    
    </div>

</div>

</div>
<?php } ?>


























 
 
<!-- ===================== end THEME SCROLLER BOX ====================== -->
<?php

$IMG1 = get_option("display_home_box_1_image");
$IMG2 = get_option("display_home_box_2_image");
$IMG3 = get_option("display_home_box_3_image");

$TITLE1 = get_option("display_home_box_1_title");
$TITLE2 = get_option("display_home_box_2_title");
$TITLE3 = get_option("display_home_box_3_title");

?>



<div class="full clearfix"><div class="f3 left" style="margin-right:4px;">
<?php if(strlen($TITLE1) > 2){ ?>
<div class="itembox" id="icon-home-bottom1">
     
        <h2><?php echo $TITLE1; ?></h2>	
        
        <div class="itemboxinner nopadding">	
 
		<?php if(strlen($IMG1) > 2){ ?>
        <img src="<?php if(get_option("display_home_box_1_image") != ""){
         echo $GLOBALS['premiumpress']['imagestorage_link'].str_replace(",","",get_option("display_home_box_1_image")); }else{ ?>
        <?php echo $GLOBALS['template_url']; ?>/images/image-1.gif<?php } ?>" alt="<?php echo $TITLE1; ?>" class="HomeImageBottom" />
        <?php } ?>
         
        <div class="padding10"><?php echo stripslashes(get_option("display_home_box_1_text")); ?></div>        
    
     
     </div>			
            
</div>
<?php } ?>
</div>
		
<div class="f3 left" style="margin-right:4px;">
<?php if(strlen($TITLE2) > 2){ ?>
<div class="itembox" id="icon-home-bottom2">
     
        <h2><?php echo $TITLE2; ?></h2>	
        
        <div class="itemboxinner nopadding">	
        
        <?php if(strlen($IMG2) > 2){ ?>
        <img src="<?php if(get_option("display_home_box_2_image") != ""){
         echo $GLOBALS['premiumpress']['imagestorage_link'].str_replace(",","",get_option("display_home_box_2_image")); }else{ ?>
        <?php echo $GLOBALS['template_url']; ?>/images/image-1.gif<?php } ?>" alt="<?php echo $TITLE2; ?>" class="HomeImageBottom" />
        <?php } ?>
        
        <div class="padding10"><?php echo stripslashes(get_option("display_home_box_2_text")); ?></div>
        
        </div>
        
 </div>
<?php } ?>
</div>                 
                

			
<div class="f3 left">
<?php if(strlen($TITLE3) > 2){ ?>
<div class="itembox" id="icon-home-bottom3">
     
        <h2><?php echo get_option("display_home_box_3_title"); ?></h2>	
        
        <div class="itemboxinner nopadding">	
        
        <?php if(strlen($IMG3) > 2){ ?>
        <img src="<?php if(get_option("display_home_box_3_image") != ""){
         echo $GLOBALS['premiumpress']['imagestorage_link'].str_replace(",","",get_option("display_home_box_3_image")); }else{ ?>
        <?php echo $GLOBALS['template_url']; ?>/images/image-1.gif<?php } ?>" alt="<?php echo $TITLE3; ?>" class="HomeImageBottom" /><?php } ?>
        
        <div class="padding10"><?php echo stripslashes(get_option("display_home_box_3_text")); ?></div>
        
        </div>
        
        </div>                 
                
</div>
<?php } ?>		
</div>










  
     

 
    
  
 
 
 
 <div class="clearfix"></div>
 
 
<?php get_footer(); ?> 