<li>
		<div class="side1">
            
		<a href="<?php echo get_permalink($post->ID)?>" title="<?php echo $post->post_title ?>">
                
			<img src="<?php echo $PPT->Image($post->ID,"url"); ?>" alt="<?php echo $post->post_title ?>&amp;w=80&amp;h=70" style="width:80px; height:70px;"/>
                
		</a>    
	       
		</div>     
                
		<h3><?php echo $post->post_title?></h3>
        
        <span><?php echo $PPT->Price(get_post_meta($post->ID, "price", true),$GLOBALS['premiumpress']['currency_symbol'],$GLOBALS['premiumpress']['currency_position'],1); ?></span>

		<p><small><?php echo $post->post_excerpt ?></small></p>
 
		<div class="clearfix"></div>
        
 
        <div class="RPoptionslist-wrapper clearfix">
           
              <div class="RPoptionslist">
              
              <a href="<?php echo get_permalink($post->ID) ?>" title="<?php echo $post->post_title?>" class="ohits"><?php echo SPEC($GLOBALS['_LANG']['_mored']) ?></a>  
              <a class="addthis_button oshare" href="http://www.addthis.com/bookmark.php"><?php echo SPEC($GLOBALS['_LANG']['_item1']) ?></a>
              <?php /* addthis:url="<?php echo get_permalink($post->ID); ?>"	addthis:title="<?php echo $post->post_title; ?>"	addthis:description="<?php echo $post->post_excerpt; ?>"*/ ?>
              <a  href="javascript:void(0);" class="ochart"><?php echo get_post_meta($post->ID, 'hits', true); ?> <?php echo SPEC($GLOBALS['_LANG']['_item2']) ?></a> 
              
              <a href="<?php echo $GLOBALS['premiumpress']['contact_url']; ?>?report=<?php echo $post->ID; ?>" class="oreport"><?php echo SPEC($GLOBALS['_LANG']['_item3']) ?></a> 
            
              </div>
                       
           
       </div> 
            
   	<div class="clearfix"><br /></div>
            
</li>