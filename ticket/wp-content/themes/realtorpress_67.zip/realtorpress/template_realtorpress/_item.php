<?php
/*
LAST UPDATED: 27th March 2011
EDITED BY: MARK FAIL
*/
global $ThemeDesign;
?>

<div class="itembox <?php if(get_post_meta($post->ID, "featured", true) == "yes"){?>hightlighted<?php }else{ ?><?php } ?>">
    
    
 
        <div class="itemboxinner">    
    
            <div class="post clearfix"> 
                                          
                <div class="thumbnail-large"> 
                
                    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                        <img src="<?php echo $PPT->Image($post->ID,"url","&amp;w=200"); ?>" class="listImage" alt="<?php the_title(); ?>" />
                    </a> 
                    
                 	<div class="info">
                    
						 <?php echo $ThemeDesign->SINGLE_IMAGEGALLERY(get_post_meta($post->ID, "images", true),3,get_post_meta($post->ID, "image", true),50,$post->ID); ?>
                         
                         
               		</div>   
                    
                </div> 
                
               
                <div class="text">
                
                
                <h1 class="icon-search-item"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> <?php if(function_exists('wp_gdsr_render_article')){ wp_gdsr_render_article(5);}  ?> </h1><br />
                
                 
                
                
                
           <ul class="item_stats" style="margin:0;">
				<li class="price"><strong><?php echo $PPT->Price(get_post_meta($post->ID, "price", true),$GLOBALS['premiumpress']['currency_symbol'],$GLOBALS['premiumpress']['currency_position'],1); ?></strong></li>
				<li class="beds"><?php echo get_post_meta($post->ID, "bedrooms", true)." ".SPEC($GLOBALS['_LANG']['_bedrooms']); ?></li>
                <li class="baths"><?php echo get_post_meta($post->ID, "bathrooms", true)." ".SPEC($GLOBALS['_LANG']['_bathrooms']); ?></li>
			</ul>
              <div class="clearfix"></div>  
                
              <?php the_excerpt(); ?> 
                    
                   <!-- <div class="tags clearfix"> <?php the_tags( '', ' ', ''); ?></div>--> 
                
                
                
        <div class="RPoptionslist-wrapper clearfix">
           
              <div class="RPoptionslist">
              
              <a href="<?php echo get_permalink($post->ID)?>" title="<?php echo $post->post_title?>" class="ohits"><?php echo SPEC($GLOBALS['_LANG']['_mored']) ?></a>  
              <a class="addthis_button oshare" href="http://www.addthis.com/bookmark.php"><?php echo SPEC($GLOBALS['_LANG']['_item1']) ?></a>
              <?php /*addthis:url="<?php echo get_permalink($post->ID); ?>"	addthis:title="<?php echo $post->post_title; ?>"	addthis:description="<?php echo $post->post_excerpt; ?>" */ ?>
              <a  href="javascript:void();" class="ochart"><?php echo get_post_meta($post->ID, 'hits', true); ?> <?php echo SPEC($GLOBALS['_LANG']['_item2']) ?></a>
              <a href="<?php echo $GLOBALS['premiumpress']['contact_url']; ?>?report=<?php echo $post->ID; ?>" class="oreport"><?php echo SPEC($GLOBALS['_LANG']['_item3']) ?></a> 
            
              </div>
                       
           
       </div>  
    
                    
                </div>
            
            </div> 
     
    
        </div>
        
    <div style="clear:both;"></div>
    
</div>