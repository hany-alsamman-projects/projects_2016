<?php if(!isset($GLOBALS['nosidebar'])){ get_sidebar(); } ?>
 
    </div> <!-- end CONTENT -->

</div> <!-- end SIDEBAR -->



 

    <div id="footer" class="clearfix full">
    
        <div class="w_960" style="margin:0 auto;"> 
        
            <div class="b_third_col col first_col"> 
            
             <div class="prepend">
			 
			 <?php echo stripslashes(get_option("footer_text")); ?>
             
             <?php if(function_exists('dynamic_sidebar')){ dynamic_sidebar('Footer Left Block (1/3)'); } ?>
             
             </div>
             
            </div>
            
            <div class="b_third_col col"> 
            
             	<?php $ArticleData = $PPT->Articles(10); if(strlen($ArticleData) > 5){ ?>
                         
                <h3><?php echo SPEC($GLOBALS['_LANG']['_rarticles']) ?></h3>   
                             
                <ul class="recentarticles"><?php echo $ArticleData; ?></ul>
                
                <?php } ?>
                
                <?php if(function_exists('dynamic_sidebar')){ dynamic_sidebar('Footer Middle Block (2/3)'); } ?>
                
            </div>
                            
            <div class="b_third_col col last_col">                
                
                <div class="topper"><?php echo $PPT->Banner("footer");  ?></div>
                
                <?php if(function_exists('dynamic_sidebar')){ dynamic_sidebar('Footer Right Block (3/3)'); } ?>
                        
            </div>
            
            
        <div class="clearfix"></div>
                        
        <div id="copyright" class="full">
            <p>&copy; <?php echo date("Y"); ?> <?php echo get_option("copyright"); ?> <?php $PPT->Copyright(); ?></p>
        </div> 
                        
    
    </div> 
        
 

</div>  <!-- end WRAPPER -->

        
</div>



<?php wp_footer(); ?>

 
</body>
</html>