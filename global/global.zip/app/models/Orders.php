<?php

class Orders extends Eloquent {


    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'orders';

}